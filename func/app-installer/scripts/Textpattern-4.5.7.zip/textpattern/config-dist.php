<?php

	/**
	 *  mysql database
	 */
		$txpcfg['db'] = '##DB_NAME_HERE##';

	/**
	 *  database login name
	 */
		$txpcfg['user'] = '##DB_USER_HERE##';

	/**
	 *  database password
	 */
		$txpcfg['pass'] = '##DB_PASS_HERE##';

	/**
	 *  database host
	 */

		$txpcfg['host'] = '##DB_HOST_HERE##';
		
	/**
	 *  table prefix (Use ONLY if you require multiple installs in one db)
	 */

		$txpcfg['table_prefix'] = '##TPREF_HERE##';

	/**
	 *  full server path to textpattern dir (no slash at end)
	 */

		$txpcfg['txpath'] = '##D_HERE##';
		
	/**
	 *  DB Connection Charset, only for MySQL4.1 and up. Must be equal to the Table-Charset.
	 */

		$txpcfg['dbcharset'] = 'latin1';

	/**
	 *  optional: database client flags as needed (@see http://www.php.net/manual/function.mysql-connect.php)
	 */

	#	$txpcfg['client_flags'] = MYSQL_CLIENT_SSL | MYSQL_CLIENT_COMPRESS;

	/**
	 *  optional, advanced: http address of the site serving images
	 *  @see http://forum.textpattern.com/viewtopic.php?id=34493
	 */

	# define('ihu', 'http://static.example.com/');

?>