SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES ##CHARSET## */;

CREATE TABLE IF NOT EXISTS `##TPREF##textpattern` (
`ID` int(11) NOT NULL,
  `Posted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `AuthorID` varchar(64) NOT NULL DEFAULT '',
  `LastMod` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LastModID` varchar(64) NOT NULL DEFAULT '',
  `Title` varchar(255) NOT NULL DEFAULT '',
  `Title_html` varchar(255) NOT NULL DEFAULT '',
  `Body` mediumtext NOT NULL,
  `Body_html` mediumtext NOT NULL,
  `Excerpt` text NOT NULL,
  `Excerpt_html` mediumtext NOT NULL,
  `Image` varchar(255) NOT NULL DEFAULT '',
  `Category1` varchar(128) NOT NULL DEFAULT '',
  `Category2` varchar(128) NOT NULL DEFAULT '',
  `Annotate` int(2) NOT NULL DEFAULT '0',
  `AnnotateInvite` varchar(255) NOT NULL DEFAULT '',
  `comments_count` int(8) NOT NULL DEFAULT '0',
  `Status` int(2) NOT NULL DEFAULT '4',
  `textile_body` int(2) NOT NULL DEFAULT '1',
  `textile_excerpt` int(2) NOT NULL DEFAULT '1',
  `Section` varchar(128) NOT NULL DEFAULT '',
  `override_form` varchar(255) NOT NULL DEFAULT '',
  `Keywords` varchar(255) NOT NULL DEFAULT '',
  `url_title` varchar(255) NOT NULL DEFAULT '',
  `custom_1` varchar(255) NOT NULL DEFAULT '',
  `custom_2` varchar(255) NOT NULL DEFAULT '',
  `custom_3` varchar(255) NOT NULL DEFAULT '',
  `custom_4` varchar(255) NOT NULL DEFAULT '',
  `custom_5` varchar(255) NOT NULL DEFAULT '',
  `custom_6` varchar(255) NOT NULL DEFAULT '',
  `custom_7` varchar(255) NOT NULL DEFAULT '',
  `custom_8` varchar(255) NOT NULL DEFAULT '',
  `custom_9` varchar(255) NOT NULL DEFAULT '',
  `custom_10` varchar(255) NOT NULL DEFAULT '',
  `uid` varchar(32) NOT NULL DEFAULT '',
  `feed_time` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

INSERT INTO `##TPREF##textpattern` (`ID`, `Posted`, `AuthorID`, `LastMod`, `LastModID`, `Title`, `Title_html`, `Body`, `Body_html`, `Excerpt`, `Excerpt_html`, `Image`, `Category1`, `Category2`, `Annotate`, `AnnotateInvite`, `comments_count`, `Status`, `textile_body`, `textile_excerpt`, `Section`, `override_form`, `Keywords`, `url_title`, `custom_1`, `custom_2`, `custom_3`, `custom_4`, `custom_5`, `custom_6`, `custom_7`, `custom_8`, `custom_9`, `custom_10`, `uid`, `feed_time`) VALUES (1, now(), '##ADMIN_USER##', now(), '', 'Welcome to Your Site!', '', 'h3. What do you want to do next?\n\n* Modify or even delete this article? The \"article list\":##SITEURL##/textpattern/index.php?event=list is the place to start.\n* Change this site\'s name, or modify the style of the URLs? It\'s all up to your \"preferences\":##SITEURL##/textpattern/index.php?event=prefs.\n* Get yourself acquainted with Textile, the humane web text generator which comes with Textpattern? The basics are \"simple\":http://textpattern.com/textile-sandbox. If you want to learn more about Textile, you can dig into an \"extensive manual\":http://textpattern.com/textile-reference-manual later.\n* Be guided through your \"Textpattern first steps\":http://textpattern.com/textpattern-first-steps by completing some basic tasks?\n* Study the \"Textpattern Semantic Model?\":http://textpattern.com/textpattern-semantic-model\n* Add \"another user\":##SITEURL##/textpattern/index.php?event=admin, or extend the capabilities with \"third party plugins\":##SITEURL##/textpattern/index.php?event=plugin you discovered from the central plugin directory at \"Textpattern Resources\":http://textpattern.org/?\n* Dive in and learn by trial and error? Then please note:\n** When you \"write\":##SITEURL##/textpattern/index.php?event=article an article you assign it to a section of your site.\n** Sections use a \"page template\":##SITEURL##/textpattern/index.php?event=page and a \"style\":##SITEURL##/textpattern/index.php?event=css as an output scaffold.\n** Page templates use HTML and Textpattern tags (like this: @<txp:article />@) to build the markup.\n** Some Textpattern tags use \"forms\":##SITEURL##/textpattern/index.php?event=form, which are building blocks for reusable snippets of code and markup you may build and use at your discretion.\n\nThere are a host of \"Frequently Asked Questions\":http://textpattern.com/faq/ to help you get started.\n\n\"Textpattern tags\":http://textpattern.com/textpattern-tag-reference, their attributes and values are as well explained as sampled at the \"User Documentation\":http://textpattern.net/, where you will also find valuable tips and tutorials.\n\nIf all else fails, there\'s a whole crowd of friendly, helpful people over at the \"Textpattern support forum\":http://forum.textpattern.com/. Come and pay a visit!\n', '\t<h3>What do you want to do next?</h3>\n\n\t<ul>\n\t\t<li>Modify or even delete this article? The <a href=\"##SITEURL##/textpattern/index.php?event=list\">article list</a> is the place to start.</li>\n\t\t<li>Change this site&#8217;s name, or modify the style of the <span class=\"caps\">URL</span>s? It&#8217;s all up to your <a href=\"##SITEURL##/textpattern/index.php?event=prefs\">preferences</a>.</li>\n\t\t<li>Get yourself acquainted with Textile, the humane web text generator which comes with Textpattern? The basics are <a href=\"http://textpattern.com/textile-sandbox\">simple</a>. If you want to learn more about Textile, you can dig into an <a href=\"http://textpattern.com/textile-reference-manual\">extensive manual</a> later.</li>\n\t\t<li>Be guided through your <a href=\"http://textpattern.com/textpattern-first-steps\">Textpattern first steps</a> by completing some basic tasks?</li>\n\t\t<li>Study the <a href=\"http://textpattern.com/textpattern-semantic-model\">Textpattern Semantic Model?</a></li>\n\t\t<li>Add <a href=\"##SITEURL##/textpattern/index.php?event=admin\">another user</a>, or extend the capabilities with <a href=\"##SITEURL##/textpattern/index.php?event=plugin\">third party plugins</a> you discovered from the central plugin directory at <a href=\"http://textpattern.org/\">Textpattern Resources</a>?</li>\n\t\t<li>Dive in and learn by trial and error? Then please note:\n\t<ul>\n\t\t<li>When you <a href=\"##SITEURL##/textpattern/index.php?event=article\">write</a> an article you assign it to a section of your site.</li>\n\t\t<li>Sections use a <a href=\"##SITEURL##/textpattern/index.php?event=page\">page template</a> and a <a href=\"##SITEURL##/textpattern/index.php?event=css\">style</a> as an output scaffold.</li>\n\t\t<li>Page templates use <span class=\"caps\">HTML</span> and Textpattern tags (like this: <code>&lt;txp:article /&gt;</code>) to build the markup.</li>\n\t\t<li>Some Textpattern tags use <a href=\"##SITEURL##/textpattern/index.php?event=form\">forms</a>, which are building blocks for reusable snippets of code and markup you may build and use at your discretion.</li>\n\t</ul></li>\n\t</ul>\n\n\t<p>There are a host of <a href=\"http://textpattern.com/faq/\">Frequently Asked Questions</a> to help you get started.</p>\n\n\t<p><a href=\"http://textpattern.com/textpattern-tag-reference\">Textpattern tags</a>, their attributes and values are as well explained as sampled at the <a href=\"http://textpattern.net/\">User Documentation</a>, where you will also find valuable tips and tutorials.</p>\n\n\t<p>If all else fails, there&#8217;s a whole crowd of friendly, helpful people over at the <a href=\"http://forum.textpattern.com/\">Textpattern support forum</a>. Come and pay a visit!</p>', '', '', '', 'hope-for-the-future', 'meaningful-labor', 1, '', 1, 4, 1, 1, 'articles', '', '', 'welcome-to-your-site', '', '', '', '', '', '', '', '', '', '',  MD5(''), now());


CREATE TABLE IF NOT EXISTS `##TPREF##txp_category` (
`id` int(6) NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `type` varchar(64) NOT NULL DEFAULT '',
  `parent` varchar(64) NOT NULL DEFAULT '',
  `lft` int(6) NOT NULL DEFAULT '0',
  `rgt` int(6) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(12, 'root', 'file', '', 1, 2, 'root');
INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(11, 'root', 'image', '', 1, 2, 'root');
INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(10, 'root', 'link', '', 1, 4, 'root');
INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(9, 'root', 'article', '', 1, 8, 'root');
INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(5, 'hope-for-the-future', 'article', 'root', 2, 3, 'Hope for the Future');
INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(6, 'meaningful-labor', 'article', 'root', 4, 5, 'Meaningful Labor');
INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(7, 'reciprocal-affection', 'article', 'root', 6, 7, 'Reciprocal Affection');
INSERT INTO `##TPREF##txp_category` (`id`, `name`, `type`, `parent`, `lft`, `rgt`, `title`) VALUES(8, 'textpattern', 'link', 'root', 2, 3, 'Textpattern');

CREATE TABLE IF NOT EXISTS `##TPREF##txp_css` (
  `name` varchar(255) NOT NULL,
  `css` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET##;

INSERT INTO `##TPREF##txp_css` (`name`, `css`) VALUES('default', '/* ==========================================================================\n   Styling and layout for all media\n   ========================================================================== */\n\n/* HTML5 display definitions\n   ========================================================================== */\n\n/**\n * Correct `block` display not defined for any HTML5 element in IE 8/9.\n * Correct `block` display not defined for `details` or `summary` in IE 10/11 and Firefox.\n * Correct `block` display not defined for `main` in IE 11.\n */\narticle,\naside,\ndetails,\nfigcaption,\nfigure,\nfooter,\nheader,\nmain,\nnav,\nsection,\nsummary {\n  display: block;\n}\n\n/**\n * 1. Correct `inline-block` display not defined in IE 8/9.\n * 2. Normalize vertical alignment of `progress` in Chrome, Firefox, and Opera.\n */\naudio,\ncanvas,\nprogress,\nvideo {\n  /* 1 */\n  display: inline-block;\n  /* 2 */\n  vertical-align: baseline;\n}\n\n/**\n * Prevent modern browsers from displaying `audio` without controls.\n * Remove excess height in iOS 5 devices.\n */\naudio:not([controls]) {\n  display: none;\n  height: 0;\n}\n\n/**\n * Address `[hidden]` styling not present in IE 8/9/10.\n * Hide the `template` element in IE 8/9/11, Safari, and Firefox < 22.\n */\n[hidden],\ntemplate {\n  display: none;\n}\n\n/**\n * 1. Always force scrollbar padding so we don''t get ''jumping''.\n * 2. Prevent iOS text size adjust after orientation change, without disabling\n *    user zoom.\n * 3. As 2 above, for Windows Phone.\n */\nhtml {\n  -webkit-tap-highlight-color: rgba(0, 102, 255, 0.5);\n  /* 1 */\n  overflow-y: scroll;\n  /* 2 */\n  -webkit-text-size-adjust: 100%;\n  /* 3 */\n  -ms-text-size-adjust: 100%;\n}\n\n/**\n * Address style set to `bolder` in Firefox 4+, Safari, and Chrome.\n */\nb,\nstrong {\n  font-weight: bold;\n}\n\n/**\n * Prevent `sub` and `sup` affecting `line-height` in all browsers.\n */\nsub,\nsup {\n  /* 12px */\n  font-size: 0.8571429em;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}\n\nsup {\n  top: -0.5em;\n}\n\nsub {\n  bottom: -0.25em;\n}\n\n/**\n * 1. Remove the gap between images and the bottom of their containers.\n * 2. Remove border when inside `a` element in IE 8-10.\n */\nimg {\n  /* 1 */\n  vertical-align: middle;\n  /* 2 */\n  border: 0;\n}\n\n/**\n * Consistent tables.\n */\ntable {\n  margin-bottom: 1em;\n  border-collapse: collapse;\n  border-spacing: 0;\n  width: 100%;\n}\n\n/**\n * Make table cells align top and left by default.\n */\nth,\ntd {\n  vertical-align: top;\n  text-align: left;\n}\n\n/**\n * Address paddings set differently.\n */\nmenu,\nol,\nul {\n  padding: 0 0 0 2em;\n}\n\n/**\n * Remove margins from nested lists.\n */\nli > ul,\nli > ol {\n  margin: 0;\n}\n\n/**\n * Address margins set differently.\n */\ndd {\n  margin: 0 0 0 2em;\n}\n\n/**\n * Italicise definition terms.\n */\ndt {\n  font-style: italic;\n}\n\n/* Clearfix\n   ========================================================================== */\n\n/**\n * Clearfix using the ''A new micro cleafix hack'' method.\n *\n * More info: http://nicolasgallagher.com/micro-clearfix-hack/\n */\n.clearfix:after,\nheader:after,\nnav ul:after,\n.container:after,\nfooter:after,\n#paginator:after,\n#monthly-list:after {\n  content: "";\n  display: table;\n  clear: both;\n}\n\n\n/* ==========================================================================\n   Styling and layout for screen media (mobile first)\n   ========================================================================== */\n\n@media screen {\n\n/* Layout\n   ========================================================================== */\n\n/**\n * 1. Remove default margin.\n */\nbody {\n  /* 1 */\n  margin: 0;\n  background: #f7f7f7;\n}\n\n/**\n * Outer wrapper for main layouts.\n *\n * Example HTML:\n *\n * <div class="wrapper">\n *     <div class="container">\n *         Content\n *     </div>\n * </div>\n */\n.wrapper {\n  border-bottom: solid 1px #ccc;\n  padding-top: 2em;\n  background: #fff;\n}\n\n/**\n * Wrapper for layouts, and for header/footer.\n *\n * Example HTML:\n *\n * <div class="wrapper">\n *     <div class="container">\n *         Content\n *     </div>\n * </div>\n */\nheader,\n.container,\nfooter {\n  margin: 0 auto;\n  /* 960px / 1024px */\n  width: 93.75%;\n  max-width: 86em;\n}\n\n/**\n * Additional styling for child content within `header`.\n */\nheader {\n  padding: 1em 0;\n}\n\nheader h1 {\n  margin: 0;\n}\n\nheader h3 {\n  /* 14px margin top */\n  margin: 0.6666667em 0 0;\n}\n\nnav {\n  border-top: solid 1px #e1a61a;\n  border-bottom: solid 1px #e1a61a;\n  background-color: #ffda44;\n  background-image: -webkit-linear-gradient(#ffda44, #fabc2b);\n  background-image: linear-gradient(#ffda44, #fabc2b);\n}\n\nnav h1 {\n  display: none;\n}\n\nnav ul {\n  margin: 0 auto;\n  padding: 0;\n  max-width: 86em;\n  list-style: none;\n  list-style-image: none;\n}\n\nnav li {\n  margin: 0;\n  border-bottom: solid 1px #e1a61a;\n}\n\nnav li:last-child {\n  border-bottom: 0;\n}\n\nnav li:hover,\nnav li.active {\n  background-color: #ffe477;\n  background-image: -webkit-linear-gradient(#ffe477, #fbcc5d);\n  background-image: linear-gradient(#ffe477, #fbcc5d);\n}\n\nnav li:active {\n  background-color: #fabc2b;\n  background-image: -webkit-linear-gradient(#fabc2b, #ffda44);\n  background-image: linear-gradient(#fabc2b, #ffda44);\n}\n\nnav a {\n  text-shadow: 1px 1px 0 rgba(255, 255, 255, 0.5);\n  display: block;\n  padding: 0.5em 3.125%;\n  color: #333;\n}\n\n/**\n * Styling for articles.\n *\n * 1. Prevent really, really long words in article from breaking layout.\n */\n[role="article"] {\n  margin-bottom: 2em;\n  /* 1 */\n  word-wrap: break-word;\n}\n\n/**\n * Styling for sidebar.\n *\n * Initially the sidebar appears under main content, it is then repositioned\n * with media queries at 2nd breakpoint.\n *\n * 1. Prevent really, really long words in article from breaking layout.\n */\n[role="complementary"] {\n  margin-bottom: 2em;\n  padding-top: 2em;\n  border-top: dashed 2px #ccc;\n  /* 1 */\n  word-wrap: break-word;\n}\n\n[role="search"] p {\n  margin-top: 0;\n}\n\n/**\n * Additional styling for child content within `footer`.\n */\nfooter {\n  padding: 0.5em 0;\n}\n\n/* Links\n   ========================================================================== */\n\n/**\n * 1. Remove default underline style from non-hover state links.\n * 2. Specify link colour.\n * 3. Remove the gray background color from active links in IE 10.\n */\na {\n  /* 1 */\n  text-decoration: none;\n  /* 2 */\n  color: #114eb1;\n  /* 3 */\n  background-color: transparent;\n}\n\n/**\n * Improve readability when focused and also mouse hovered in all browsers.\n */\na:hover,\na:active {\n  outline: 0;\n}\n\na:focus {\n  outline: thin dotted #06f;\n}\n\n/**\n * Additional styling for child links within `header`.\n */\nheader a {\n  color: #333;\n  border-radius: 0.1190476em;\n}\n\nheader a:hover, header a:active {\n  background: #e8e8e8;\n}\n\n[role="main"] a:hover,\n[role="main"] a:active,\n[role="complementary"] a:hover,\n[role="complementary"] a:active,\nfooter a:hover,\nfooter a:active {\n  text-decoration: underline;\n  color: #06f;\n}\n\n[role="main"] a:visited,\n[role="complementary"] a:visited,\nfooter a:visited {\n  color: #183082;\n}\n\n/**\n * Additional styling for `h1` heading links.\n */\n[role="main"] h1 a {\n  color: #333;\n  border-radius: 0.1190476em;\n}\n\n[role="main"] h1 a:visited {\n  color: #333;\n}\n\n[role="main"] h1 a:hover,\n[role="main"] h1 a:active {\n  text-decoration: none;\n  color: #333;\n  background: #efefef;\n}\n\n/* Typography\n   ========================================================================== */\n\nbody {\n  font-family: "PT Serif", Georgia, serif;\n  /* 14px / 16px */\n  font-size: 0.875em;\n  line-height: 1.5;\n  color: #333;\n}\n\nnav {\n  font-family: Arial, Helvetica, sans-serif;\n  font-weight: bold;\n}\n\nh1 {\n  font-family: Arial, Helvetica, sans-serif;\n  /* 28px */\n  font-size: 2em;\n  /* 34px / 28px */\n  line-height: 1.2142857;\n  letter-spacing: -1px;\n  /* 28px margin top/bottom */\n  margin: 0.6666667em 0;\n}\n\nh1:first-child {\n  margin-top: 0;\n}\n\nh2 {\n  font-family: Arial, Helvetica, sans-serif;\n  /* 21px */\n  font-size: 1.5em;\n  /* 28px / 21px */\n  line-height: 1.3333333;\n  /* 21px margin top/bottom */\n  margin: 0.75em 0;\n}\n\nh3 {\n  /* 18px */\n  font-size: 1.28571428571429em;\n  /* 26px / 18px */\n  line-height: 1.44444444444444;\n  font-weight: normal;\n  font-style: italic;\n  /* 16px margin top/bottom */\n  margin: 0.7619048em 0;\n}\n\nh4 {\n  font-family: Arial, Helvetica, sans-serif;\n  /* 16px */\n  font-size: 1.1428571em;\n  margin: 0;\n}\n\n/**\n * Additional styling for blockquotes.\n */\nblockquote {\n  /* 16px */\n  font-size: 1.1428571em;\n  font-style: italic;\n  margin: 0.875em 0 0.875em 0;\n  padding: 1px 0.875em;\n  border-radius: 0.3571429em;\n  background: #fff6d3;\n}\n\n/**\n * Add vertical margin to addresses.\n */\naddress {\n  margin: 1em 0;\n}\n\n/**\n * Address styling not present in IE 8/9/10/11, Safari, and Chrome.\n */\nabbr[title],\ndfn[title] {\n  border-bottom: dotted 1px;\n  cursor: help;\n}\n\ndfn,\nmark,\nq,\nvar {\n  padding: 0 0.2142857em;\n  border-radius: 0.2142857em;\n  color: #333;\n  background: #fff6d3;\n}\n\n/**\n * Address styling not present in Safari and Chrome.\n */\ndfn,\nq {\n  font-style: italic;\n}\n\nvar {\n  font-weight: bold;\n}\n\npre,\ncode,\nkbd,\nsamp {\n  font-family: Cousine, Consolas, "Lucida Console", Monaco, monospace;\n}\n\ncode,\nkbd,\nsamp {\n  /* 13px */\n  font-size: 0.9285714em;\n  border: 1px solid #e3e3e3;\n  padding: 0 0.2307692em;\n  border-radius: 0.2307692em;\n  background: #f7f7f7;\n}\n\npre {\n  /* 13px */\n  font-size: 0.9285714em;\n  overflow-x: auto;\n  border: 1px solid #e3e3e3;\n  padding: 1em;\n  border-radius: 0.3571429em;\n  background: #f7f7f7;\n  tab-size: 4;\n}\n\npre code {\n  /* 13px */\n  font-size: 1em;\n  border: 0;\n  background: none;\n}\n\n/**\n * Harmonise size and style of small text.\n */\nsmall,\nfigcaption,\ntfoot,\n.footnote {\n  /* 12px */\n  font-size: 0.8571429em;\n}\n\nfigcaption,\ntfoot,\n.footnote {\n  color: #888;\n}\n\nfigcaption {\n  margin-top: 0.3333333em;\n  font-style: italic;\n}\n\n/* Support for non-latin languages (can be removed if not required)\n   ========================================================================== */\n\n/**\n * Preferred font for Japanese language.\n */\nhtml[lang="ja-jp"] {\n  font-family: "Hiragino Kaku Gothic Pro", Meiryo, sans-serif;\n}\n\n/**\n * Preferred font for Korean language.\n */\nhtml[lang="ko-kr"] {\n  font-family: GulimChe, Gulim, sans-serif;\n}\n\n/**\n * Preferred font for Chinese (PRC) language.\n */\nhtml[lang="zh-cn"] {\n  font-family: SimHei, sans-serif;\n}\n\n/**\n * Preferred font for Chinese (Taiwan) language.\n */\nhtml[lang="zh-tw"] {\n  font-family: PMingLiU, sans-serif;\n}\n\n/* Embedded content\n   ========================================================================== */\n\n/**\n * Make embedded elements responsive.\n */\nimg,\nvideo {\n  max-width: 100%;\n  height: auto;\n}\n\n/**\n * Address margin not present in IE 8/9 and Safari.\n */\nfigure {\n  margin: 0;\n}\n\n/**\n * Image alignment (compatible with Textile markup syntax).\n *\n * Example HTML:\n *\n * <img class="align-left">\n * <img class="align-right">\n * <img class="align-center">\n */\nimg.align-left {\n  float: left;\n  margin: 1em 1em 1em 0;\n}\nimg.align-right {\n  float: right;\n  margin: 1em 0 1em 1em;\n}\nimg.align-center {\n  display: block;\n  margin: 1em auto;\n}\n\n/**\n * Correct overflow not hidden in IE 9/10/11.\n */\nsvg:not(:root) {\n  overflow: hidden;\n}\n\n/* Tables\n   ========================================================================== */\n\n/**\n * Styling of table captions.\n */\ncaption {\n  font-style: italic;\n  text-align: left;\n  margin-bottom: 0.5em;\n}\n\nth,\ntd {\n  border-bottom: solid 1px #ccc;\n  padding: 0.2857143em 0.5em 0.2857143em 0;\n}\n\nth:last-child,\ntd:last-child {\n  padding-right: 0;\n}\n\nthead th,\nthead td {\n  border-bottom: solid 2px #ccc;\n}\n\ntfoot th,\ntfoot td {\n  border-bottom: 0;\n  padding: 0.3333333em 0.5833333em 0.3333333em 0;\n}\n\ntfoot:last-child {\n  padding-right: 0;\n}\n\n/* Lists\n   ========================================================================== */\n\n/**\n * Italicise definition terms.\n */\ndt {\n  font-style: italic;\n}\n\n/**\n * Additional styling for article lists.\n *\n * Example HTML:\n *\n * <ul class="article-list">\n */\n[role="main"] #article-list {\n  list-style: none;\n  margin: 0 0 2em 0;\n  padding: 0;\n  border-top: solid 1px #ccc;\n}\n\n#article-list li {\n  border-bottom: solid 1px #ccc;\n  padding-top: 1em;\n  margin-bottom: 0;\n}\n\n/* Forms\n   ========================================================================== */\n\n/**\n * 1. Define consistent fieldset border, margin, and padding.\n * 2. Address width being affected by wide descendants in Chrome, Firefox.\n */\nfieldset {\n  /* 1 */\n  margin: 1em 0;\n  border: 1px solid #cccccc;\n  padding: 1px 1em;\n  /* 2 */\n  min-width: 0;\n}\n\n/**\n * 1. Correct `color` not being inherited in IE 8/9/10/11.\n * 2. Remove padding so people aren''t caught out if they zero out fieldsets.\n */\nlegend {\n  /* 1 */\n  border: 0;\n  /* 2 */\n  padding: 0;\n}\n\n/**\n * 1. Correct font properties not being inherited.\n * 2. Address margins set differently in Firefox 4+, Safari, and Chrome.\n * 3. Prevent elements from spilling out of their parent.\n */\nbutton,\ninput,\nselect,\ntextarea {\n  /* 1 */\n  font-size: 100%;\n  /* 2 */\n  margin: 0;\n  /* 3 */\n  max-width: 100%;\n  vertical-align: baseline;\n}\n\n/**\n * Colour for placeholder text.\n */\ninput::-moz-placeholder,\ntextarea::-moz-placeholder {\n  color: #888888;\n}\ninput:-ms-input-placeholder,\ntextarea:-ms-input-placeholder {\n  color: #888888;\n}\ninput::-webkit-input-placeholder,\ntextarea::-webkit-input-placeholder {\n  color: #888888;\n}\n\n/**\n * Remove inner padding and border in Firefox 4+.\n */\nbutton::-moz-focus-inner,\ninput::-moz-focus-inner {\n  border: 0;\n  padding: 0;\n}\n\n/**\n * Remove inner padding and search cancel button in Safari and Chrome on OS X.\n * Safari (but not Chrome) clips the cancel button when the search input has\n * padding (and `textfield` appearance).\n */\ninput[type="search"]::-webkit-search-cancel-button,\ninput[type="search"]::-webkit-search-decoration {\n  -webkit-appearance: none;\n}\n\nbutton:focus,\na.button:focus,\ninput:focus,\ninput[type="button"]:focus,\ninput[type="reset"]:focus,\ninput[type="submit"]:focus,\nselect:focus,\ntextarea:focus {\n  -webkit-box-shadow: 0 0 7px #0066ff;\n  box-shadow: 0 0 7px #0066ff;\n  /* Opera */\n  z-index: 1;\n}\n\ninput[type="file"]:focus,\ninput[type="file"]:active,\ninput[type="radio"]:focus,\ninput[type="radio"]:active,\ninput[type="checkbox"]:focus,\ninput[type="checkbox"]:active {\n  -webkit-box-shadow: none;\n  box-shadow: none;\n}\n\n/**\n * Styling of form input fields.\n *\n * 1. Remove iOS Safari default styling.\n */\ntextarea,\ninput[type="color"],\ninput[type="date"],\ninput[type="datetime"],\ninput[type="datetime-local"],\ninput[type="email"],\ninput[type="month"],\ninput[type="number"],\ninput[type="password"],\ninput[type="search"],\ninput[type="tel"],\ninput[type="text"],\ninput[type="time"],\ninput[type="url"],\ninput[type="week"] {\n  /* 1 */\n  -webkit-appearance: none;\n  font-family: Arial, Helvetica, sans-serif;\n  /* 12px */\n  font-size: 0.8571429em;\n  text-align: left;\n  border: solid 1px #ccc;\n  padding: 0.5em;\n  background: #fff;\n  outline: 0;\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n  border-radius: 0;\n}\n\n/**\n * Remove padding from `color` fields.\n */\ninput[type="color"] {\n  padding: 0;\n  height: 2.33333333333333em;\n}\n\n/**\n * Inline search field on sidebar.\n */\n[role="complementary"] input[type="search"] {\n  margin-right: 2px;\n  width: 66.666666666667%;\n  display: inline-block;\n}\n\n/**\n * 1. Remove default vertical scrollbar in IE 8/9/10/11.\n * 2. Restrict to vertical resizing to prevent layout breakage.\n */\ntextarea {\n  min-height: 3em;\n  vertical-align: top;\n  width: 100%;\n  height: auto;\n  /* 1 */\n  overflow: auto;\n  /* 2 */\n  resize: vertical;\n}\n\n/**\n * 1. Correct `select` style inheritance in Firefox.\n */\nselect {\n  font-family: Arial, Helvetica, sans-serif;\n  /* 12px */\n  font-size: 0.8571429em;\n  text-align: left;\n  border: solid 1px #ccc;\n  padding: 0.5em;\n  background: #fff;\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n  /* 1 */\n  text-transform: none;\n}\n\n/**\n * Override height set in a previous rule and allow auto heght.\n */\nselect[size],\nselect[multiple] {\n  height: auto;\n}\n\n/**\n * Normalise styling of `optgroup`.\n */\noptgroup {\n  font-family: Arial, Helvetica, sans-serif;\n  font-style: normal;\n  font-weight: normal;\n  color: #333;\n}\n\n/**\n * Remove excess padding in IE 8/9/10.\n */\ninput[type="checkbox"],\ninput[type="radio"] {\n  padding: 0;\n}\n\n/**\n * Make sure disabled elements really are disabled and styled appropriately.\n *\n * 1. Override default iOS opacity setting.\n * 2. Re-set default cursor for disabled elements.\n */\nbutton[disabled],\ninput[disabled],\ninput[type="button"][disabled],\ninput[type="reset"][disabled],\ninput[type="submit"][disabled],\nselect[disabled],\nselect[disabled] option,\nselect[disabled] optgroup,\ntextarea[disabled],\nspan.disabled {\n  /* 1 */\n  opacity: 1;\n  -webkit-user-select: none;\n  -moz-user-select: -moz-none;\n  user-select: none;\n  border: solid 1px #d2d2d2 !important;\n  text-shadow: none !important;\n  color: #888888 !important;\n  background: #eee !important;\n  top: 0 !important;\n  /* 2 */\n  cursor: default !important;\n}\n\n/**\n * Width display options for `input` fields. Height display options\n * for textareas.\n *\n * Example HTML:\n *\n * <input class="small">\n * <input class="large">\n */\n.small input {\n  width: 25%;\n  min-width: 151px;\n}\n.small textarea {\n  height: 5.5em;\n}\n.large input {\n  width: 50%;\n  min-width: 302px;\n}\n.large textarea {\n  height: 156px;\n}\n\n/* Buttons\n   ========================================================================== */\n\n/**\n * 1. Address `overflow` set to `hidden` in IE 8/9/10/11.\n * 2. Correct `button` style inheritance in Firefox, IE 8/9/10/11, and Opera.\n */\nbutton {\n  /* 1 */\n  overflow: visible;\n  /* 2 */\n  text-transform: none;\n}\n\n/**\n * 1. Remove iOS Safari default styling.\n * 2. Improve usability and consistency of cursor style between image-type\n *    `input` and others.\n */\nbutton,\n[role] a.button,\nspan.disabled,\ninput[type="button"],\ninput[type="reset"],\ninput[type="submit"] {\n  /* 1 */\n  -webkit-appearance: none;\n  -webkit-background-clip: padding;\n  -moz-background-clip: padding;\n  background-clip: padding-box;\n  width: auto;\n  font-family: Arial, Helvetica, sans-serif;\n  /* 12px */\n  font-size: 0.8571429em;\n  font-weight: normal;\n  line-height: normal;\n  text-align: center;\n  text-decoration: none;\n  text-shadow: 1px 1px 0 rgba(255, 255, 255, 0.5);\n  border: solid 1px #e1a61a;\n  border-radius: 0.3571429em;\n  padding: 0.5em 1em;\n  display: inline-block;\n  color: #333;\n  outline: 0;\n  background-color: #ffda44;\n  background-image: -webkit-linear-gradient(#ffda44, #fabc2b);\n  background-image: linear-gradient(#ffda44, #fabc2b);\n  /* 2 */\n  cursor: pointer;\n}\n\nbutton:hover,\n[role] a.button:hover,\ninput[type="button"]:hover,\ninput[type="reset"]:hover,\ninput[type="submit"]:hover {\n  background-color: #ffe477;\n  background-image: -webkit-linear-gradient(#ffe477, #fbcc5d);\n  background-image: linear-gradient(#ffe477, #fbcc5d);\n}\n\nbutton:active,\n[role] a.button:active,\ninput[type="button"]:active,\ninput[type="reset"]:active,\ninput[type="submit"]:active {\n  position: relative;\n  top: 1px;\n  color: #1a1a1a;\n  background-color: #fabc2b;\n  background-image: -webkit-linear-gradient(#fabc2b, #ffda44);\n  background-image: linear-gradient(#fabc2b, #ffda44);\n}\n\n#paginator {\n  margin-bottom: 2em;\n}\n\n#paginator .button {\n  padding: 0.25em 1em;\n}\n\n#paginator a.button {\n  text-decoration: none;\n  color: #333;\n}\n\n#paginator-l {\n  float: left;\n}\n\n#paginator-r {\n  float: right;\n}\n\n/* Comments\n   ========================================================================== */\n\n.comments {\n  margin-bottom: 1em;\n  border-radius: 0.3571429em;\n  padding: 1em 1em 1px;\n  background: #f7f7f7;\n  word-wrap: break-word;\n}\n\n.comments h4 .is-author {\n  font-weight: normal;\n}\n\n.comments h4 .comment-anchor {\n  float: right;\n  font-weight: normal;\n }\n\n/**\n * Additional styling for article author''s comments.\n */\n.comments-author {\n  background: #efefef;\n}\n\n/**\n * Styling for user comments preview.\n */\n#cpreview {\n  margin-bottom: 2px;\n  border-radius: 0.3571429em;\n  padding: 1em;\n  background: #fff3d6;\n}\n\n/**\n * Highlight background colour for comment errors.\n */\n.comments_error {\n  background: #fff4f4 !important;\n}\n\n/**\n * Highlight text colour for comment errors.\n */\n.error_message li {\n  color: #c00;\n}\n\n/**\n * Styling for ''required'' indicators.\n */\n.required {\n  color: #c00;\n  cursor: help;\n}\n\n/* Popup comments (can be removed if you don''t use popups)\n   ========================================================================== */\n\n#popup-page .wrapper {\n  padding-top: 0;\n}\n\n/**\n * Restrict maximum width of popup container.\n */\n#popup-page .container {\n  max-width: 52em;\n}\n\n}\n\n/**\n * Addresses select alignment in Safari/Chrome.\n */\n@media screen and (-webkit-min-device-pixel-ratio: 0) {\n\nselect,\nselect[size="0"],\nselect[size="1"] {\n  height: 2.2em;\n}\n\nselect:not([size]),\nselect:not([multiple]) {\n  position: relative;\n  top: -1px;\n}\n\n}\n\n\n/* ==========================================================================\n   Additional layout for screen media 490px and up\n   ========================================================================== */\n\n@media only screen and (min-width: 35em) {\n\nnav ul {\n  width: 93.75%;\n}\n\nnav li {\n  float: left;\n  border-right: solid 1px #e1a61a;\n  border-bottom: 0;\n}\n\nnav li:first-child {\n  border-left: solid 1px #e1a61a;\n}\n\nnav a {\n  padding: 0.5em 1em;\n}\n\n}\n\n\n/* ==========================================================================\n   Additional layout for screen media 672px and up\n   ========================================================================== */\n\n@media only screen and (min-width: 48em) {\n\n[role="main"] {\n  float: left;\n  /* 592px / 960px */\n  width: 61.666666666667%;\n}\n\n[role="complementary"] {\n  float: right;\n  border: 1px solid #e3e3e3;\n  border-radius: 0.3571429em;\n  padding: 1em 1em 0;\n  /* 290px / 960px */\n  width: 30.208333333333%;\n  background: #f7f7f7;\n}\n\nh1 {\n  /* 42px */\n  font-size: 3em;\n}\n\nh2 {\n  /* 28px */\n  font-size: 2em;\n}\n\nh3 {\n  /* 21px */\n  font-size: 1.5em;\n}\n\nblockquote {\n  float: right;\n  margin: 0 0 0.875em 0.875em;\n  /* 254px / 592px */\n  width: 42.905405405405%;\n}\n\n}\n\n\n/* ==========================================================================\n   Additional layout for screen media 1280px and up\n   ========================================================================== */\n\n@media only screen and (min-width: 80em) {\n\nbody {\n  /* 16px */\n  font-size: 100%;\n}\n\nheader,\nnav ul,\n.container,\nfooter {\n  /* 1152px / 1280px */\n  width: 90%;\n}\n\n}\n\n\n/* ==========================================================================\n   Additional layout for screen media 1800px and up\n   ========================================================================== */\n\n@media only screen and (min-width: 112.5em) {\n\nbody {\n  /* 18px */\n  font-size: 112.5%;\n}\n\n}\n\n\n/* ==========================================================================\n   Fix for reponsive embedded content in IE8\n   ========================================================================== */\n\n@media \\0screen {\n\nimg,\nvideo {\n  width: auto;\n}\n\n}\n\n\n/* ==========================================================================\n   Styling and layout for print media\n   ========================================================================== */\n\n@media print {\n\n/**\n * Remove unnecessary global styling from printed media.\n *\n * 1. Black prints faster.\n */\n* {\n  -webkit-box-shadow: none !important;\n  box-shadow: none !important;\n  /* 1 */\n  color: black !important;\n  text-shadow: none !important;\n  background: transparent !important;\n}\n\n/**\n * Use a print-friendly font and size.\n */\nbody {\n  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;\n  font-size: 8pt;\n  line-height: 1.5;\n  margin: 0.5cm;\n  padding: 2em 5em;\n}\n\n/**\n * Visually separate header from body.\n */\nheader {\n  border-bottom: solid 1pt black;\n}\n\n/**\n * Visually separate footer from body.\n */\nfooter {\n  margin-top: 12pt;\n  border-top: solid 1pt black;\n}\n\n/**\n * Hide unnecessary content from print.\n */\nnav,\naudio,\nvideo,\nform,\n[role="complementary"],\n#paginator,\n#comments-form,\n.comments h4 a:last-child {\n  display: none;\n}\n\n/**\n * Make sure links are not underlined.\n */\na {\n  text-decoration: none;\n}\n\n/**\n *  Show long-form for abbreviations in print.\n */\nabbr[title]:after {\n  content: " (" attr(title) ")";\n}\n\nh1 {\n  font-size: 32pt;\n  line-height: 36pt;\n  font-weight: normal;\n  margin: 0.5em 0;\n}\n\nh2 {\n  font-size: 18pt;\n  line-height: 23pt;\n  page-break-after: avoid;\n  orphans: 3;\n  widows: 3;\n  margin: 0.6666667em 0;\n}\n\nh3 {\n  font-size: 12pt;\n  line-height: 17pt;\n  page-break-after: avoid;\n  orphans: 3;\n  widows: 3;\n  margin: 0.6666667em 0;\n}\n\n/**\n * Prevent widows (single final paragraph line on next page) and orphans (single\n * first paragraph line on previous page).\n */\np {\n  orphans: 3;\n  widows: 3;\n}\n\n/**\n * Harmonise size and style of small text.\n */\nfooter,\nfigcaption,\ntfoot,\nsmall,\n.footnote {\n  font-size: 6pt;\n}\n\n/**\n * Simple blockquote styling.\n *\n * 1. Avoid blockquotes breaking across mutiple pages.\n */\nblockquote {\n  font-size: 16pt;\n  border-left: 3pt solid black;\n  padding: 0 0 0 8pt;\n  /* 1 */\n  page-break-inside: avoid;\n}\n\n/**\n * Simple preformatted text styling.\n */\npre {\n  margin-bottom: 8pt;\n  border: solid 1pt black;\n  padding: 8pt;\n}\n\n/**\n * Avoid user comments breaking across mutiple pages.\n */\n.comments {\n  page-break-inside: avoid;\n}\n\n/**\n * Use a print-friendly monospaced font and size.\n */\npre,\ncode,\nkbd,\nsamp,\nvar {\n  font-family: "Courier New", Courier, monospace;\n}\n\n/**\n * Italic definitons, quotes and definition terms.\n */\ndfn,\nq,\ndt {\n  font-style: italic;\n}\n\n/**\n * 1. Ensure images are maximum possible width.\n * 2. Avoid images breaking across mutiple pages.\n */\nimg {\n  /* 1 */\n  max-width: 100% !important;\n  /* 2 */\n  page-break-inside: avoid;\n}\n\n/**\n * Image alignment (compatible with Textile markup syntax).\n *\n * Example HTML:\n *\n * <img class="align-left">\n * <img class="align-right">\n * <img class="align-center">\n */\nimg.align-left {\n  float: left;\n  margin: 1em 1em 1em 0;\n}\nimg.align-right {\n  float: right;\n  margin: 1em 0 1em 1em;\n}\nimg.align-center {\n  display: block;\n  margin: 1em auto;\n}\n\n/**\n * Ensure margin below `figure`.\n */\nfigure {\n  margin-bottom: 8pt;\n}\n\n/**\n * Ensure margin above `figcaption`.\n */\nfigcaption {\n  margin-top: 4pt;\n}\n\n/**\n * Simple bullet styling for `ul` unordered lists.\n */\nul {\n  list-style: square;\n  padding: 0 0 8pt 1.8em;\n}\n\n/**\n * Simple numerical styling for `ol` ordered lists.\n */\nol {\n  list-style: decimal;\n  padding: 0 0 8pt 1.8em;\n}\n\n/**\n * Normalise margins on `dl` definition lists.\n */\ndl {\n  padding: 0 0 8pt 1.8em;\n}\n\n/**\n * 1. Ensure margin below `table`.\n * 2. Make `table` span entire page width.\n */\ntable {\n  /* 1 */\n  margin-bottom: 8pt;\n  /* 2 */\n  width: 100%;\n}\n\n/**\n * Harmonise styling for `caption`.\n */\ncaption {\n  font-weight: bold;\n  text-align: left;\n  margin-bottom: 4pt;\n}\n\n/**\n * Display table head across multi-page tables.\n */\nthead {\n  display: table-header-group;\n}\nthead th {\n  border-top: 1pt solid black;\n}\n\n/**\n * Avoid table rows breaking across mutiple pages.\n */\ntr {\n  page-break-inside: avoid;\n}\n\n/**\n * Simple styling for table cells.\n */\nth,\ntd {\n  border-bottom: solid 1pt black;\n  padding: 4pt 8pt;\n}\n\n}\n');

CREATE TABLE IF NOT EXISTS `##TPREF##txp_discuss` (
`discussid` int(6) unsigned zerofill NOT NULL,
  `parentid` int(8) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(254) NOT NULL DEFAULT '',
  `web` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(100) NOT NULL DEFAULT '',
  `posted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message` text NOT NULL,
  `visible` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

INSERT INTO `##TPREF##txp_discuss` (`discussid`, `parentid`, `name`, `email`, `web`, `ip`, `posted`, `message`, `visible`) VALUES(000001, 1, 'Donald Swain', 'donald.swain@example.com', 'example.com', '127.0.0.1', NOW(), '<p>I enjoy your site very much.</p>', 1);

CREATE TABLE IF NOT EXISTS `##TPREF##txp_discuss_ipban` (
  `ip` varchar(255) NOT NULL DEFAULT '',
  `name_used` varchar(255) NOT NULL DEFAULT '',
  `date_banned` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `banned_on_message` int(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET##;

CREATE TABLE IF NOT EXISTS `##TPREF##txp_discuss_nonce` (
  `issue_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nonce` varchar(255) NOT NULL DEFAULT '',
  `used` tinyint(4) NOT NULL DEFAULT '0',
  `secret` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET##;

CREATE TABLE IF NOT EXISTS `##TPREF##txp_file` (
`id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `category` varchar(255) NOT NULL DEFAULT '',
  `permissions` varchar(32) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `downloads` int(4) unsigned NOT NULL DEFAULT '0',
  `status` smallint(6) NOT NULL DEFAULT '4',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `size` bigint(20) DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET## PACK_KEYS=0;

CREATE TABLE IF NOT EXISTS `##TPREF##txp_form` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `type` varchar(28) NOT NULL DEFAULT '',
  `Form` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('article_listing', 'article', '<txp:if_first_article><ul id="article-list"></txp:if_first_article>\n  <li role="article" itemscope itemtype="http://schema.org/Article">\n    <h4 itemprop="name"><a href="<txp:permlink />" itemprop="url"><txp:title /></a></h4>\n\n    <!-- if the article has an excerpt, display that -->\n    <txp:if_excerpt>\n      <div itemprop="description">\n        <txp:excerpt />\n      </div>\n    </txp:if_excerpt>\n\n    <p class="footnote"><txp:text item="posted" /> <time datetime="<txp:posted format=''iso8601'' />" itemprop="datePublished"><txp:posted /></time>, <txp:text item="author" /> <span itemprop="author"><txp:author link="1" this_section="1" /></span></p>\n  </li>\n<txp:if_last_article></ul></txp:if_last_article>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('comments', 'comment', '<!-- load the comment email into a variable. you will be using below this along with author email variable loaded in form: default.article.txp\n  then check the comment email variable against article author email variable, and if it matches add ''comments-author'' class -->\n<txp:variable name="this_comment" value=''<txp:comment_email />'' />\n<txp:if_variable name="this_comment" value=''<txp:author_email />''>\n  <article class="comments comments-author" itemprop="comment">\n<txp:else />\n  <article class="comments" itemprop="comment">\n</txp:if_variable>\n\n  <h4>\n\n  <span itemprop="creator"><txp:comment_name /></span>\n\n  <!-- ...now check the comment email variable against article author email variable, and if it matches add ''(author)'' text -->\n  <txp:if_variable name="this_comment" value=''<txp:author_email />''>\n    <span class="is-author">(<txp:text item="author" />)</span>\n  </txp:if_variable>\n\n  <!-- add a permlink so people can link direct to this comment -->\n    <span class="comment-anchor" itemprop="url"><txp:comment_permlink>#</txp:comment_permlink></span>\n\n  </h4>\n\n  <!-- also add a ''since'' to show comment freshness -->\n  <p class="footnote"><time datetime="<txp:comment_time format=''iso8601'' />" itemprop="commentTime"><txp:comment_time /> (<txp:comment_time format="since" />)</time></p>\n\n  <div itemprop="commentText">\n    <txp:comment_message />\n  </div>\n\n</article>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('comments_display', 'article', '<!-- added an id attribute to the section so we can link directly to here e.g. http://mysite.com/section/article#comments-head -->\n\n<section id="comments-head">\n\n<h3><txp:text item="comments" /></h3>\n\n<!-- if there are comments, display them (note: example code below overrides the global preference setting for comments wrapping by stating\n  attributes of wraptag="" and break="", you are instead using ol and li tags below)... -->\n<txp:if_comments>\n  <ol class="comments-list" itemscope itemtype="http://schema.org/UserComments">\n\n    <txp:comments wraptag="" break="li" /> <!-- links by default to form: ''comments.comment.txp'' unless you specify a different form -->\n\n  <!-- if this is a comment preview, display it (but only if there is no error) -->\n    <txp:if_comments_preview>\n      <li>\n        <p id="cpreview"><txp:text item="press_preview_then_submit" /></p>\n        <txp:comments_preview wraptag="" /> <!-- links by default to form: ''comments.comment.txp'' unless you specify a different form -->\n      </li>\n    </txp:if_comments_preview>\n\n  </ol>\n\n<txp:else />\n\n<!-- else if there are no comments and if user is currently previewing comment,display it (but only if there is no error) -->\n  <txp:if_comments_preview>\n    <ol class="comments-list" itemscope itemtype="http://schema.org/UserComments">\n      <li>\n        <p id="cpreview"><txp:text item="press_preview_then_submit" /></p>\n        <txp:comments_preview wraptag="" /> <!-- links by default to form: ''comments.comment.txp'' unless you specify a different form -->\n      </li>\n    </ol>\n\n  <txp:else />\n\n<!-- else just display that there are simply no comments whatsoever :( ...but only if comments are allowed -->\n    <txp:if_comments_allowed>\n      <p><txp:text item="no_comments" /></p>\n    </txp:if_comments_allowed>\n\n  </txp:if_comments_preview>\n\n</txp:if_comments>\n\n<!-- if new comments are allowed for this article then display comment form, if not then display ''closed'' messages -->\n<txp:if_comments_allowed>\n  <section id="comments-form">\n\n    <!-- comment invite text is taken for the article''s comment invitation field on the ''write'' screen -->\n    <h3><txp:comments_invite showcount="0" textonly="1" showalways="1" /></h3>\n\n    <txp:comments_form isize="32" msgcols="64" msgrows="4" /> <!-- links by default to form: ''comment_form.comment.txp'' unless you specify a different form -->\n  </section>\n\n<txp:else />\n  \n  <!-- display either a comments expired message or a comments disabled message -->\n  <txp:if_comments>\n    <p><strong><txp:text item="comments_expired" /></strong></p>\n  <txp:else />\n    <p><strong><txp:text item="comments_closed" /></strong></p>\n  </txp:if_comments>\n</txp:if_comments_allowed>\n\n</section>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('comment_form', 'comment', '<txp:comments_error wraptag="ul" break="li" />\n\n<txp:comments_error wraptag="ul" break="li" />\n\n<p><txp:text item="enter_comment_here" /></p>\n\n<!-- if there is an error, then inform user -->\n<txp:if_comments_error>\n  <txp:comments_error wraptag="ol" break="li" class="error_message" />\n</txp:if_comments_error>\n\n<fieldset>\n\n  <p class="large"><label for="name"><txp:text item="comment_name" /> <b class="required" title="<txp:text item=''required'' />">*</b></label><br>\n  <txp:comment_name_input /></p>\n\n  <p class="large"><label for="email"><txp:text item="comment_email" /> <b class="required" title="<txp:text item=''required'' />">*</b></label><br>\n  <txp:comment_email_input /></p>\n\n  <p class="large"><label for="web"><txp:text item="comment_web" /></label><br>\n  <txp:comment_web_input /></p>\n\n  <p><txp:comment_remember /></p>\n\n  <p class="small"><label for="message"><txp:text item="comment_message" /> <b class="required" title="<txp:text item=''required'' />">*</b></label><br>\n  <txp:comment_message_input /></p>\n\n</fieldset>\n\n<!-- preview and submit buttons (note: submit button will have a class of ''disabled'' applied until you have previewed the message at least once) -->\n<p><txp:comment_preview /> <txp:comment_submit /></p>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('default', 'article', '<article role="article" itemscope itemtype="http://schema.org/Article">\n\n<!-- if not an individual article then make the title h1 a link -->\n<txp:if_individual_article>\n  <h1 itemprop="name"><txp:title /></h1>\n<txp:else />\n  <h1 itemprop="name"><a href="<txp:permlink />" itemprop="url"><txp:title /></a></h1>\n</txp:if_individual_article>\n\n  <p><strong><txp:text item="posted" /></strong> <time datetime="<txp:posted format=''iso8601'' />" itemprop="datePublished"><txp:posted /></time><br>\n    <strong><txp:text item="comments" /></strong> <a href="<txp:permlink />#comments-head" title="<txp:text item=''view'' />&#8230;" itemprop="discussionUrl" itemscope itemtype="http://schema.org/UserComments">\n\n<!-- if comments then display the number, if no comments then print ''none'' -->\n<txp:if_comments>\n  <span itemprop="interactionCount"><txp:comments_count /></span>\n<txp:else />\n  <span itemprop="interactionCount"><txp:text item="none" /></span>\n</txp:if_comments>\n\n  </a></p>\n\n  <div itemprop="articleBody">\n    <txp:body />\n  </div>\n\n  <p><strong><txp:text item="author" /></strong> <span itemprop="author"><txp:author link="1" this_section="1" /></span>\n\n  <!-- only display categories if they are actually set for an article, otherwise omit -->\n  <txp:if_article_category>\n    <br><strong><txp:text item="categories" /></strong> <span itemprop="keywords"><txp:category1 title="1" link="1" /><txp:if_article_category number="1"><txp:if_article_category number="2">, </txp:if_article_category></txp:if_article_category><txp:category2 title="1" link="1" /></span>\n  </txp:if_article_category>\n\n  </p>\n\n<!-- if this is an individual article then add the comments section via form: comments_display.article.txp -->\n<txp:if_individual_article>\n  <txp:article form="comments_display" />\n</txp:if_individual_article>\n\n</article>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('files', 'file', '<!-- set up variables to check whether a file also has a title, description, category associated with it... -->\n<txp:variable name="file_download_title" value=''<txp:file_download_name title="1" />'' />\n<txp:variable name="file_download_description" value=''<txp:file_download_description />'' />\n<txp:variable name="file_download_category" value=''<txp:file_download_category />'' />\n\n<div itemscope itemtype="http://schema.org/DataDownloads">\n\n  <!-- ...if exists, use the file title, otherwise use file name -->\n  <txp:if_variable name="file_download_title" value="">\n    <strong itemprop="name"><a href="<txp:file_download_link />" title="<txp:file_download_name />" itemprop="url"><txp:file_download_name /></a></strong><br>\n  <txp:else />\n    <strong itemprop="name"><a href="<txp:file_download_link />" title="<txp:file_download_name title=''1'' />" itemprop="url"><txp:file_download_name title="1" /></a></strong><br>\n  </txp:if_variable>\n\n  <!-- ...if exists, use the file description, otherwise omit that line -->\n  <txp:if_variable name="file_download_description" value="">\n  <txp:else />\n  <span itemprop="description"><txp:file_download_description /></span><br>\n  </txp:if_variable>\n\n  <span class="footnote">\n\n  <!-- ...if exists, use the file category, otherwise omit that line -->\n  <txp:if_variable name="file_download_category" value="">\n  <txp:else />\n    <strong><txp:text item="category" /></strong> <txp:file_download_category /> &#124; \n  </txp:if_variable>\n\n    <strong><txp:text item="author" /></strong> <txp:file_download_author link="1" /> &#124; \n    <strong><txp:text item="file_size" /></strong> <txp:file_download_size /> &#124; \n    <strong><txp:text item="last_modified" /></strong> <span itemprop="dateModified"><txp:file_download_created /></span> &#124; \n    <strong><txp:text item="download_count" /></strong> <span itemprop="interactionCount"><txp:file_download_downloads /></span>\n\n  </span>\n\n</div>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('images', 'misc', '<!-- set up a variable to check whether a image also has a caption associated with it... -->\n<txp:variable name="caption" value=''<txp:image_info type="caption" />'' />\n\n<!-- ...now use that image caption and wrap img inside a figure with figcaption tags, otherwise just use a plain img tag -->\n<txp:if_variable name="caption" value="">\n\n<!-- image - overriding the width and height to let the image scale to fit parent container -->\n  <p><txp:image width="0" height="0" /></p>\n\n<txp:else />\n\n  <figure itemscope itemtype="http://schema.org/ImageObject">\n\n<!-- image - overriding the width and height to let the image scale to fit parent container -->\n    <txp:image width="0" height="0" />\n\n<!-- you do not need to specify the attribute type="caption" as that is the default setting for <txp:image_info /> tag -->\n    <figcaption itemprop="caption"><txp:image_info type="caption" /></figcaption>\n\n  </figure>\n\n</txp:if_variable>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('plainlinks', 'link', '<!-- This is being used as an external links form, therefore rel is set to ''external'' -->\n<txp:linkdesctitle rel="external" />\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('popup_comments', 'comment', '<!DOCTYPE html>\n<html lang="<txp:lang />">\n\n<head>\n  <meta charset="utf-8">\n\n  <title><txp:page_title /></title>\n  <meta name="generator" content="Textpattern CMS">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <meta name="robots" content="noindex, follow, noodp, noydir">\n\n  <!-- CSS -->\n  <!-- Google font API (remove this if you intend to use the theme in a project without internet access) -->\n  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Serif:n4,i4,n7,i7|Cousine">\n\n  <txp:css format="link" media="" />\n  <!-- ...or you can use (faster) external CSS files eg. <link rel="stylesheet" href="<txp:site_url />css/default.css"> -->\n\n  <!-- HTML5/Media Queries support for IE < 9 (you can remove this section and the corresponding ''js'' directory files if you don''t intend to support IE < 9) -->\n  <!--[if lt IE 9]>\n    <script src="<txp:site_url />js/html5shiv.js"></script>\n    <script src="<txp:site_url />js/css3-mediaqueries.js"></script>\n  <![endif]-->\n\n</head>\n\n<body id="popup-page">\n\n  <div class="wrapper">\n    <div class="container">\n\n      <!-- this form is only used if you set ''Comments mode'' to ''popup'' format in preferences -->\n      <txp:popup_comments />\n\n    </div> <!-- /.container -->\n  </div> <!-- /.wrapper -->\n\n</body>\n</html>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('search_input', 'misc', '<form role="search" method="get" action="<txp:site_url />">\n  <h4><label for="search-textbox"><txp:text item="search" /></label></h4>\n  <p><input id="search-textbox" type="search" name="q"<txp:if_search> value="<txp:search_term />"</txp:if_search>><input type="submit" value="<txp:text item=''go'' />"></p>\n</form>\n');
INSERT INTO `##TPREF##txp_form` (`name`, `type`, `Form`) VALUES('search_results', 'article', '<txp:if_search>\n\n<!-- count how many results return -->\n  <txp:article limit="10" pgonly="1" />\n\n  <txp:if_search_results>\n\n<!-- if search result count greater than 200 then display excessive results message, otherwise show search result count -->\n    <txp:if_search_results max="200">\n      <h3><txp:search_result_count /> <txp:text item="matching_search_request" /> &#8216;<txp:search_term />&#8217;&#8230;</h3>\n    <txp:else />\n      <h3><txp:text item="too_common_search_term" /> &#8216;<txp:search_term />&#8217;</h3>\n    </txp:if_search_results>\n\n<!-- if no search results, then display no search results message -->\n  <txp:else />\n    <h3><txp:text item="no_search_matches" /></h3>\n\n  </txp:if_search_results>\n\n<!-- display resulting articles (10 per page) -->\n  <txp:article limit="10">\n\n    <txp:if_first_article><ul id="article-list"></txp:if_first_article>\n      <li role="article" itemscope itemtype="http://schema.org/Article">\n        <h4 itemprop="name"><a href="<txp:permlink />" itemprop="url"><txp:title /></a></h4>\n\n<!-- if the article has an excerpt, display that, otherwise show highlighted keywords in context of article -->\n        <txp:if_excerpt>\n          <div itemprop="description">\n            <txp:excerpt />\n          </div>\n        <txp:else />\n          <p><txp:search_result_excerpt /></p>\n        </txp:if_excerpt>\n\n        <p class="footnote"><txp:text item="posted" /> <time datetime="<txp:posted format=''iso8601'' />" itemprop="datePublished"><txp:posted /></time>, <txp:text item="author" /> <span itemprop="author"><txp:author link="1" this_section="1" /></span></p>\n      </li>\n    <txp:if_last_article></ul></txp:if_last_article>\n\n  </txp:article>\n\n<!-- check if there are further results and provide pagination links or disabled buttons depending on the result,\n  this method is more flexibile than using simple txp:older/txp:newer tags -->\n  <txp:if_search_results min="11">\n\n    <p id="paginator">\n\n    <txp:variable name="prev" value=''<txp:older />'' />\n    <txp:variable name="next" value=''<txp:newer />'' />\n\n    <txp:if_variable name="next" value="">\n      <span id="paginator-l" class="button disabled">&#8592; <txp:text item="prev" /></span>\n    <txp:else />\n      <a id="paginator-l" href="<txp:newer />" title="&#8592; <txp:text item="prev" />" class="button">&#8592; <txp:text item="prev" /></a>\n    </txp:if_variable>\n    <txp:if_variable name="prev" value="">\n      <span id="paginator-r" class="button disabled"><txp:text item="next" /> &#8594;</span>\n    <txp:else />\n      <a id="paginator-r" href="<txp:older />" title="<txp:text item="next" /> &#8594;" class="button"><txp:text item="next" /> &#8594;</a>\n    </txp:if_variable>\n\n    </p>\n\n  </txp:if_search_results>\n\n</txp:if_search>\n');

CREATE TABLE IF NOT EXISTS `##TPREF##txp_image` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `category` varchar(255) NOT NULL DEFAULT '',
  `ext` varchar(20) NOT NULL DEFAULT '',
  `w` int(8) NOT NULL DEFAULT '0',
  `h` int(8) NOT NULL DEFAULT '0',
  `alt` varchar(255) NOT NULL DEFAULT '',
  `caption` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `author` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` int(2) NOT NULL DEFAULT '0',
  `thumb_w` int(8) NOT NULL DEFAULT '0',
  `thumb_h` int(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET## PACK_KEYS=0;

CREATE TABLE IF NOT EXISTS `##TPREF##txp_lang` (
`id` int(9) NOT NULL,
  `lang` varchar(16) NOT NULL,
  `name` varchar(64) NOT NULL,
  `event` varchar(64) NOT NULL,
  `data` tinytext,
  `lastmod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=1159 DEFAULT CHARSET=##CHARSET##;

INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1, 'en-gb', 'add_new_author', '##ADMIN_USER##', 'Add new author',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(2, 'en-gb', 'and_mailed_to', '##ADMIN_USER##', 'and emailed to',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(3, 'en-gb', 'assign_assets_to', '##ADMIN_USER##', 'Assign userâ€™s content to',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(4, 'en-gb', 'author_already_exists', '##ADMIN_USER##', 'Author <strong>{name}</strong> already exists.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(5, 'en-gb', 'author_deleted', '##ADMIN_USER##', 'Author <strong>{name}</strong> deleted.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(6, 'en-gb', 'author_updated', '##ADMIN_USER##', 'Author <strong>{name}</strong> updated.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(7, 'en-gb', 'a_message_will_be_sent_with_login', '##ADMIN_USER##', 'A message will be sent with login information.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(8, 'en-gb', 'a_new_password_will_be_mailed', '##ADMIN_USER##', 'A new password will be emailed.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(9, 'en-gb', 'cannot_assign_assets_to_deletee', '##ADMIN_USER##', 'You cannot assign assets to a deleted account.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(10, 'en-gb', 'changeprivilege', '##ADMIN_USER##', 'Change privilege',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(11, 'en-gb', 'change_email_address', '##ADMIN_USER##', 'Change your email address',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(12, 'en-gb', 'change_password', '##ADMIN_USER##', 'Change your password',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(13, 'en-gb', 'copy_editor', '##ADMIN_USER##', 'Copy Editor',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(14, 'en-gb', 'could_not_mail', '##ADMIN_USER##', 'Could not email',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(15, 'en-gb', 'could_not_update_author', '##ADMIN_USER##', 'Could not update author.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(16, 'en-gb', 'designer', '##ADMIN_USER##', 'Designer',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(17, 'en-gb', 'edit_author', '##ADMIN_USER##', 'Edit author',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(18, 'en-gb', 'email_changed', '##ADMIN_USER##', 'Email address changed to <strong>{email}</strong>.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(19, 'en-gb', 'error_adding_new_author', '##ADMIN_USER##', 'Error adding new author.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(20, 'en-gb', 'freelancer', '##ADMIN_USER##', 'Freelancer',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(21, 'en-gb', 'last_login', '##ADMIN_USER##', 'Last log in',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(22, 'en-gb', 'login_name', '##ADMIN_USER##', 'Login',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(23, 'en-gb', 'log_in_at', '##ADMIN_USER##', 'Log in at',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(24, 'en-gb', 'mail_it', '##ADMIN_USER##', 'Email it to me',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(25, 'en-gb', 'managing_editor', '##ADMIN_USER##', 'Managing Editor',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(26, 'en-gb', 'must_reassign_assets', '##ADMIN_USER##', 'Please re-assign userâ€™s content',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(27, 'en-gb', 'new_email', '##ADMIN_USER##', 'New email',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(28, 'en-gb', 'new_password', '##ADMIN_USER##', 'New password',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(29, 'en-gb', 'password_changed', '##ADMIN_USER##', 'Password changed',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(30, 'en-gb', 'password_changed_mailed', '##ADMIN_USER##', 'Password changed and emailed to <strong>{email}</strong>.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(31, 'en-gb', 'password_forgotten', '##ADMIN_USER##', 'Forgot password?',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(32, 'en-gb', 'password_required', '##ADMIN_USER##', 'Please provide a new password.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(33, 'en-gb', 'password_reset', '##ADMIN_USER##', 'Reset password',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(34, 'en-gb', 'password_reset_button', '##ADMIN_USER##', 'Reset password',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(35, 'en-gb', 'password_reset_confirmation', '##ADMIN_USER##', 'Somebody (probably you) has requested to reset your password. Please confirm this reset request by clicking on the link below.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(36, 'en-gb', 'password_reset_confirmation_request', '##ADMIN_USER##', 'Please confirm your password reset request',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(37, 'en-gb', 'password_reset_confirmation_request_sent', '##ADMIN_USER##', 'A confirmation message was sent. Please check your email and follow the instructions.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(38, 'en-gb', 'password_sent_to', '##ADMIN_USER##', 'Password sent to',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(39, 'en-gb', 'privileges', '##ADMIN_USER##', 'Privileges',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(40, 'en-gb', 'privs_none', '##ADMIN_USER##', 'None',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(41, 'en-gb', 'publisher', '##ADMIN_USER##', 'Publisher',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(42, 'en-gb', 'real_name', '##ADMIN_USER##', 'Real name',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(43, 'en-gb', 'resetpassword', '##ADMIN_USER##', 'Reset password',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(44, 'en-gb', 'reset_author_password', '##ADMIN_USER##', 'Reset author password',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(45, 'en-gb', 'site_administration', '##ADMIN_USER##', 'Users',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(46, 'en-gb', 'staff_writer', '##ADMIN_USER##', 'Staff Writer',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(47, 'en-gb', 'unknown_author', '##ADMIN_USER##', 'Unknown author: <strong>{name}</strong>.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(48, 'en-gb', 'writer', '##ADMIN_USER##', 'Writer',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(49, 'en-gb', 'your_login_info', '##ADMIN_USER##', 'Your login info',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(50, 'en-gb', 'your_login_is', '##ADMIN_USER##', 'Your login is',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(51, 'en-gb', 'your_new_password', '##ADMIN_USER##', 'Your new password',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(52, 'en-gb', 'your_password_is', '##ADMIN_USER##', 'Your password is',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(53, 'en-gb', 'you_have_been_registered', '##ADMIN_USER##', 'You have been registered as a contributor to the site',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(54, 'en-gb', 'advanced_options', 'article', 'Advanced options',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(55, 'en-gb', 'article_day', 'article', 'Day',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(56, 'en-gb', 'article_expires_before_postdate', 'article', 'Error: Article expires <strong>before</strong> post date.',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(57, 'en-gb', 'article_exp_day', 'article', 'Day',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(58, 'en-gb', 'article_exp_hour', 'article', 'Hour',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(59, 'en-gb', 'article_exp_minute', 'article', 'Minute',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(60, 'en-gb', 'article_exp_month', 'article', 'Month',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(61, 'en-gb', 'article_exp_second', 'article', 'Second',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(62, 'en-gb', 'article_exp_year', 'article', 'Year',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(63, 'en-gb', 'article_hour', 'article', 'Hour',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(64, 'en-gb', 'article_image', 'article', 'Article image',  NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(65, 'en-gb', 'article_markup', 'article', 'Article markup', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(66, 'en-gb', 'article_minute', 'article', 'Minute', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(67, 'en-gb', 'article_month', 'article', 'Month', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(68, 'en-gb', 'article_posted', 'article', 'Article posted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(69, 'en-gb', 'article_saved', 'article', 'Article saved.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(70, 'en-gb', 'article_saved_draft', 'article', 'Article saved as draft.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(71, 'en-gb', 'article_saved_hidden', 'article', 'Article saved as hidden.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(72, 'en-gb', 'article_saved_pending', 'article', 'Article saved as pending.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(73, 'en-gb', 'article_save_failed', 'article', 'The article was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(74, 'en-gb', 'article_second', 'article', 'Second', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(75, 'en-gb', 'article_year', 'article', 'Year', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(76, 'en-gb', 'comment_settings', 'article', 'Comment options', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(77, 'en-gb', 'concurrent_edit_by', 'article', 'Article <strong>not</strong> saved. {author} modified the article while you were editing it. If youâ€™re sure, press the â€˜Saveâ€™ button once more.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(78, 'en-gb', 'date_settings', 'article', 'Date and time', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(79, 'en-gb', 'excerpt_markup', 'article', 'Excerpt markup', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(80, 'en-gb', 'expires', 'article', 'Expires', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(81, 'en-gb', 'meta', 'article', 'Meta', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(82, 'en-gb', 'no_articles_recorded', 'article', 'No articles recorded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(83, 'en-gb', 'or_publish_at', 'article', 'â€¦or publish at', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(84, 'en-gb', 'override_default_form', 'article', 'Override form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(85, 'en-gb', 'pending', 'article', 'Pending', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(86, 'en-gb', 'reset_time', 'article', 'Reset time to now', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(87, 'en-gb', 'set_to_now', 'article', 'Set timestamp to now', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(88, 'en-gb', 'sort_display', 'article', 'Sort and display', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(89, 'en-gb', 'textfilter_help', 'article', 'Text formatting help', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(90, 'en-gb', 'timestamp', 'article', 'Timestamp', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(91, 'en-gb', 'url_title', 'article', 'URL-only title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(92, 'en-gb', 'url_title_is_blank', 'article', 'URL-only title was left blank.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(93, 'en-gb', 'url_title_is_multiple', 'article', 'The same URL-only title is used by {count} different articles.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(94, 'en-gb', 'view_html', 'article', 'View HTML markup', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(95, 'en-gb', 'view_html_short', 'article', 'HTML', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(96, 'en-gb', 'view_preview', 'article', 'Preview article', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(97, 'en-gb', 'view_preview_short', 'article', 'Preview', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(98, 'en-gb', 'view_text', 'article', 'Edit article text', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(99, 'en-gb', 'view_text_short', 'article', 'Text', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(100, 'en-gb', 'write', 'article', 'Write', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(101, 'en-gb', 'article_categories_deleted', 'category', 'Article categories deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(102, 'en-gb', 'article_category', 'category', 'Article category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(103, 'en-gb', 'article_category_already_exists', 'category', 'Article category <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(104, 'en-gb', 'article_category_created', 'category', 'Article category <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(105, 'en-gb', 'article_category_invalid', 'category', 'Article category <strong>{name}</strong> invalid.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(106, 'en-gb', 'article_category_name', 'category', 'Article category name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(107, 'en-gb', 'article_category_title', 'category', 'Article category title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(108, 'en-gb', 'article_category_updated', 'category', 'Article category <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(109, 'en-gb', 'article_head', 'category', 'Article categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(110, 'en-gb', 'categories_set_parent', 'category', '{list} assigned to {type} category parent {parent}', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(111, 'en-gb', 'category_not_found', 'category', 'Category not found', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(112, 'en-gb', 'category_save_failed', 'category', 'The category was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(113, 'en-gb', 'create_new_category', 'category', 'Create new category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(114, 'en-gb', 'edit_category', 'category', 'Edit category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(115, 'en-gb', 'file_categories_deleted', 'category', 'File categories deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(116, 'en-gb', 'file_category_already_exists', 'category', 'File category <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(117, 'en-gb', 'file_category_created', 'category', 'File category <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(118, 'en-gb', 'file_category_invalid', 'category', 'File category <strong>{name}</strong> invalid.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(119, 'en-gb', 'file_category_name', 'category', 'File category name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(120, 'en-gb', 'file_category_title', 'category', 'File category title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(121, 'en-gb', 'file_category_updated', 'category', 'File category <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(122, 'en-gb', 'file_head', 'category', 'File categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(123, 'en-gb', 'image_categories_deleted', 'category', 'Image categories deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(124, 'en-gb', 'image_category_already_exists', 'category', 'Image category <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(125, 'en-gb', 'image_category_created', 'category', 'Image category <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(126, 'en-gb', 'image_category_invalid', 'category', 'Image category <strong>{name}</strong> invalid.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(127, 'en-gb', 'image_category_name', 'category', 'Image category name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(128, 'en-gb', 'image_category_title', 'category', 'Image category title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(129, 'en-gb', 'image_category_updated', 'category', 'Image category <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(130, 'en-gb', 'image_head', 'category', 'Image categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(131, 'en-gb', 'link_categories_deleted', 'category', 'Link categories deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(132, 'en-gb', 'link_category_already_exists', 'category', 'Link category <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(133, 'en-gb', 'link_category_created', 'category', 'Link category <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(134, 'en-gb', 'link_category_invalid', 'category', 'Link category <strong>{name}</strong> invalid.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(135, 'en-gb', 'link_category_name', 'category', 'Link category name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(136, 'en-gb', 'link_category_title', 'category', 'Link category title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(137, 'en-gb', 'link_category_updated', 'category', 'Link category <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(138, 'en-gb', 'link_head', 'category', 'Link categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(139, 'en-gb', 'no_categories_exist', 'category', 'None exist.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(140, 'en-gb', 'no_other_categories_exist', 'category', 'No other categories exist.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(141, 'en-gb', 'parent', 'category', 'Parent', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(142, 'en-gb', 'active', 'common', 'Active', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(143, 'en-gb', 'add', 'common', 'Add', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(144, 'en-gb', 'admin', 'common', 'Admin', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(145, 'en-gb', 'ar-ar', 'common', 'Ø¹Ø±Ø¨ÙŠ', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(146, 'en-gb', 'ar-dz', 'common', 'Ø¬Ø²Ø§Ø¦Ø±ÙŠ Ø¹Ø±Ø¨ÙŠ', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(147, 'en-gb', 'are_you_sure', 'common', 'Are you sure?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(148, 'en-gb', 'article', 'common', 'Article', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(149, 'en-gb', 'ascending', 'common', 'Ascending', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(150, 'en-gb', 'auth_required', 'common', 'Authorisation required.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(151, 'en-gb', 'back_to_login', 'common', 'â† Back to Textpattern log in', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(152, 'en-gb', 'bad_cookie', 'common', 'Your session has expired. Please log in again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(153, 'en-gb', 'bg-bg', 'common', 'Ð‘ÑŠÐ»Ð³Ð°Ñ€ÑÐºÐ¸', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(154, 'en-gb', 'body', 'common', 'Body', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(155, 'en-gb', 'bs-ba', 'common', 'Bosanski', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(156, 'en-gb', 'ca-es', 'common', 'CatalÃ ', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(157, 'en-gb', 'cannot_instantiate_theme', 'common', 'Theme <strong>{name}</strong> ({class}) failed to load properly from file {path}. The default theme will be used as a fallback.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(158, 'en-gb', 'category', 'common', 'Category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(159, 'en-gb', 'changeauthor', 'common', 'Change author', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(160, 'en-gb', 'changecategory', 'common', 'Change category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(161, 'en-gb', 'changecategory1', 'common', 'Change category1', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(162, 'en-gb', 'changecategory2', 'common', 'Change category2', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(163, 'en-gb', 'changecomments', 'common', 'Change comments', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(164, 'en-gb', 'changeparent', 'common', 'Change parent', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(165, 'en-gb', 'changesection', 'common', 'Change section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(166, 'en-gb', 'changestatus', 'common', 'Change status', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(167, 'en-gb', 'close', 'common', 'Close', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(168, 'en-gb', 'comment', 'common', 'Comment', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(169, 'en-gb', 'comments_expired', 'common', 'Commenting has expired for this article.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(170, 'en-gb', 'confirm_delete_popup', 'common', 'Really delete?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(171, 'en-gb', 'cookies_must_be_enabled', 'common', 'Browser cookies must be enabled to use Textpattern.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(172, 'en-gb', 'could_not_log_in', 'common', 'Could not log in with that username/password.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(173, 'en-gb', 'cs-cz', 'common', 'ÄŒeÅ¡tina', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(174, 'en-gb', 'da-dk', 'common', 'Dansk', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(175, 'en-gb', 'date_added', 'common', 'Date added', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(176, 'en-gb', 'de-de', 'common', 'Deutsch', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(177, 'en-gb', 'deleteforce', 'common', 'Force delete', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(178, 'en-gb', 'delete_selected', 'common', 'Delete selected', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(179, 'en-gb', 'descending', 'common', 'Descending', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(180, 'en-gb', 'description', 'common', 'Description', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(181, 'en-gb', 'detail_toggle', 'common', 'Show more detail', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(182, 'en-gb', 'draft', 'common', 'Draft', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(183, 'en-gb', 'duplicate', 'common', 'Duplicate', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(184, 'en-gb', 'el-gr', 'common', 'Î•Î»Î»Î·Î½Î¹ÎºÎ¬', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(185, 'en-gb', 'en-gb', 'common', 'English (Great Britain)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(186, 'en-gb', 'en-us', 'common', 'English (United States)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(187, 'en-gb', 'es-es', 'common', 'EspaÃ±ol', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(188, 'en-gb', 'et-ee', 'common', 'Eesti', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(189, 'en-gb', 'excerpt', 'common', 'Excerpt', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(190, 'en-gb', 'expired', 'common', 'Expired', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(191, 'en-gb', 'external_links', 'common', 'External links', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(192, 'en-gb', 'fa-ir', 'common', 'Ù¾Ø§Ø±Ø³ÛŒ', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(193, 'en-gb', 'fi-fi', 'common', 'Suomi', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(194, 'en-gb', 'form_not_found', 'common', 'Form not found', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(195, 'en-gb', 'form_not_specified', 'common', 'Form not specified.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(196, 'en-gb', 'form_submission_error', 'common', 'Sorry, the form could not be submitted. Please try again later.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(197, 'en-gb', 'fr-fr', 'common', 'FranÃ§ais', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(198, 'en-gb', 'gd_unavailable', 'common', 'unavailable', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(199, 'en-gb', 'general_error', 'common', 'General error', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(200, 'en-gb', 'get_off_my_lawn', 'common', 'Iâ€™m sorry. Iâ€™m afraid I canâ€™t do that; <code>{event}</code> <code>{step}</code> is an unsafe operation.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(201, 'en-gb', 'gl-gz', 'common', 'Galego', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(202, 'en-gb', 'greeting', 'common', 'Dear', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(203, 'en-gb', 'he-il', 'common', '×¢×‘×¨×™×ª', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(204, 'en-gb', 'hidden', 'common', 'Hidden', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(205, 'en-gb', 'hr-hr', 'common', 'Hrvatski', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(206, 'en-gb', 'hu-hu', 'common', 'Magyar', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(207, 'en-gb', 'id-id', 'common', 'Bahasa Indonesia', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(208, 'en-gb', 'image_category', 'common', 'Category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(209, 'en-gb', 'internal_error', 'common', 'Internal error', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(210, 'en-gb', 'is-is', 'common', 'Ãslenska', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(211, 'en-gb', 'it-it', 'common', 'Italiano', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(212, 'en-gb', 'ja-jp', 'common', 'æ—¥æœ¬èªž', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(213, 'en-gb', 'ko-kr', 'common', 'í•œêµ­ë§ (ëŒ€í•œë¯¼êµ­)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(214, 'en-gb', 'lang_dir', 'common', 'ltr', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(215, 'en-gb', 'last_modified', 'common', 'Last modified', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(216, 'en-gb', 'link_category', 'common', 'Category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(217, 'en-gb', 'logged_in_as', 'common', 'Logged in as', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(218, 'en-gb', 'login', 'common', 'Log in', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(219, 'en-gb', 'login_to_textpattern', 'common', 'Log in to Textpattern', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(220, 'en-gb', 'logout', 'common', 'Log out', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(221, 'en-gb', 'log_in_button', 'common', 'Log in', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(222, 'en-gb', 'lt-lt', 'common', 'LietuviÅ³', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(223, 'en-gb', 'lv-lv', 'common', 'LatvieÅ¡u', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(224, 'en-gb', 'method', 'common', 'Method', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(225, 'en-gb', 'misc', 'common', 'Miscellaneous', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(226, 'en-gb', 'modified', 'common', 'modified', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(227, 'en-gb', 'navigation', 'common', 'Navigation', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(228, 'en-gb', 'nl-nl', 'common', 'Nederlands', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(229, 'en-gb', 'no-no', 'common', 'Norsk', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(230, 'en-gb', 'no_results_found', 'common', 'No results found.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(231, 'en-gb', 'password', 'common', 'Password', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(232, 'en-gb', 'per_page', 'common', 'per page', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(233, 'en-gb', 'pl-pl', 'common', 'Polski', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(234, 'en-gb', 'pt-br', 'common', 'PortuguÃªs (Brasil)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(235, 'en-gb', 'pt-pt', 'common', 'PortuguÃªs (Portugal)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(236, 'en-gb', 'published_with', 'common', 'Published with', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(237, 'en-gb', 'range', 'common', 'Range', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(238, 'en-gb', 'restricted_area', 'common', 'Restricted area.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(239, 'en-gb', 'ro-ro', 'common', 'RomÃ¢nÄƒ', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(240, 'en-gb', 'ru-ru', 'common', 'Ð ÑƒÑÑÐºÐ¸Ð¹', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(241, 'en-gb', 'save_new', 'common', 'Save new', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(242, 'en-gb', 'showing_search_results', 'common', 'Showing {from} to {to} of {total}', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(243, 'en-gb', 'site_slogan', 'common', 'Site slogan', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(244, 'en-gb', 'sk-sk', 'common', 'SlovenÄina', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(245, 'en-gb', 'sort_value', 'common', 'Sort value', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(246, 'en-gb', 'sp-rs', 'common', 'Srpski', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(247, 'en-gb', 'spam', 'common', 'Spam', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(248, 'en-gb', 'sr-rs', 'common', 'Ð¡Ñ€Ð¿ÑÐºÐ¸', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(249, 'en-gb', 'stay_logged_in', 'common', 'Remain logged in with this browser', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(250, 'en-gb', 'sticky', 'common', 'Sticky', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(251, 'en-gb', 'structure', 'common', 'Structure', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(252, 'en-gb', 'sv-se', 'common', 'Svenska', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(253, 'en-gb', 'tab_admin', 'common', 'Admin', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(254, 'en-gb', 'tab_comments', 'common', 'Comments', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(255, 'en-gb', 'tab_content', 'common', 'Content', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(256, 'en-gb', 'tab_diagnostics', 'common', 'Diagnostics', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(257, 'en-gb', 'tab_extensions', 'common', 'Extensions', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(258, 'en-gb', 'tab_file', 'common', 'Files', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(259, 'en-gb', 'tab_forms', 'common', 'Forms', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(260, 'en-gb', 'tab_image', 'common', 'Images', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(261, 'en-gb', 'tab_import', 'common', 'Import', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(262, 'en-gb', 'tab_languages', 'common', 'Languages', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(263, 'en-gb', 'tab_link', 'common', 'Links', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(264, 'en-gb', 'tab_list', 'common', 'Articles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(265, 'en-gb', 'tab_logs', 'common', 'Visitor logs', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(266, 'en-gb', 'tab_organise', 'common', 'Categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(267, 'en-gb', 'tab_pages', 'common', 'Pages', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(268, 'en-gb', 'tab_plugins', 'common', 'Plugins', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(269, 'en-gb', 'tab_preferences', 'common', 'Preferences', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(270, 'en-gb', 'tab_presentation', 'common', 'Presentation', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(271, 'en-gb', 'tab_sections', 'common', 'Sections', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(272, 'en-gb', 'tab_site_admin', 'common', 'Users', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(273, 'en-gb', 'tab_start', 'common', 'Home', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(274, 'en-gb', 'tab_style', 'common', 'Styles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(275, 'en-gb', 'tab_view_site', 'common', 'View site', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(276, 'en-gb', 'tab_write', 'common', 'Write', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(277, 'en-gb', 'th-th', 'common', 'à¹„à¸—à¸¢', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(278, 'en-gb', 'thumbnail', 'common', 'Thumbnail', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(279, 'en-gb', 'title_body', 'common', 'Title and body', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(280, 'en-gb', 'title_body_excerpt', 'common', 'Title, body and excerpt', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(281, 'en-gb', 'toggle_all_selected', 'common', 'Toggle all/none selected', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(282, 'en-gb', 'tr-tr', 'common', 'TÃ¼rkÃ§e', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(283, 'en-gb', 'txpnl2br', 'common', 'Line breaks only', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(284, 'en-gb', 'txprawxhtml', 'common', 'Raw HTML', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(285, 'en-gb', 'txpstriptags', 'common', 'Strip tags', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(286, 'en-gb', 'txptextile', 'common', 'Textile', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(287, 'en-gb', 'txptextilelite', 'common', 'Textile Lite', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(288, 'en-gb', 'txt_quote_double_close', 'common', 'â€', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(289, 'en-gb', 'txt_quote_double_open', 'common', 'â€œ', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(290, 'en-gb', 'txt_quote_single_close', 'common', 'â€™', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(291, 'en-gb', 'txt_quote_single_open', 'common', 'â€˜', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(292, 'en-gb', 'uk-ua', 'common', 'Ð£ÐºÑ€Ð°Ñ—Ð½ÑÑŒÐºÐ°', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(293, 'en-gb', 'units_b', 'common', 'B', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(294, 'en-gb', 'units_e', 'common', 'EB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(295, 'en-gb', 'units_g', 'common', 'GB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(296, 'en-gb', 'units_k', 'common', 'kB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(297, 'en-gb', 'units_m', 'common', 'MB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(298, 'en-gb', 'units_p', 'common', 'PB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(299, 'en-gb', 'units_t', 'common', 'TB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(300, 'en-gb', 'units_y', 'common', 'YB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(301, 'en-gb', 'units_z', 'common', 'ZB', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(302, 'en-gb', 'unmoderated', 'common', 'Unmoderated', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(303, 'en-gb', 'upload_err_cant_write', 'common', 'Failed to write file to disk.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(304, 'en-gb', 'upload_err_extension', 'common', 'File upload stopped by PHP extension.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(305, 'en-gb', 'upload_err_form_size', 'common', 'File exceeds the maximum size specified in Textpatternâ€™s preferences.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(306, 'en-gb', 'upload_err_ini_size', 'common', 'File exceeds the <code>upload_max_filesize</code> directive in <code>php.ini</code>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(307, 'en-gb', 'upload_err_no_file', 'common', 'No file was specified.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(308, 'en-gb', 'upload_err_partial', 'common', 'File was only partially uploaded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(309, 'en-gb', 'upload_err_tmp_dir', 'common', 'No valid temporary directory was found. Please consult your webhost.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(310, 'en-gb', 'upload_file', 'common', 'Upload file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(311, 'en-gb', 'ur-in', 'common', 'Ø§Ø±Ø¯Ùˆ', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(312, 'en-gb', 'use_textile', 'common', 'Use Textile', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(313, 'en-gb', 'vi-vn', 'common', 'Tiáº¿ng Viá»‡t (Viá»‡t Nam)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(314, 'en-gb', 'viewsite', 'common', 'View site', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(315, 'en-gb', 'view_per_page', 'common', 'View {page} per page', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(316, 'en-gb', 'visible', 'common', 'Visible', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(317, 'en-gb', 'with_selected', 'common', 'With selected:', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(318, 'en-gb', 'with_selected_option', 'common', 'With selectedâ€¦', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(319, 'en-gb', 'zh-cn', 'common', 'ä¸­æ–‡(ç®€ä½“)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(320, 'en-gb', 'zh-tw', 'common', 'ä¸­æ–‡(ç¹é«”)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(321, 'en-gb', 'add_declaration', 'css', 'Add declaration', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(322, 'en-gb', 'add_new_selector', 'css', 'Add new selector', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(323, 'en-gb', 'all_stylesheets', 'css', 'All styles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(324, 'en-gb', 'bulkload_existing_css', 'css', 'Create or load new style', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(325, 'en-gb', 'cannot_delete_default_css', 'css', 'Style <strong>default</strong> cannot be deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(326, 'en-gb', 'copy_css_as', 'css', 'â€¦or copy style as', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(327, 'en-gb', 'create_new_css', 'css', 'Create new style', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(328, 'en-gb', 'css_already_exists', 'css', 'Style <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(329, 'en-gb', 'css_code', 'css', 'Style code', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(330, 'en-gb', 'css_created', 'css', 'Style <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(331, 'en-gb', 'css_deleted', 'css', 'Style <strong>{name}</strong> deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(332, 'en-gb', 'css_mode', 'css', 'CSS mode', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(333, 'en-gb', 'css_name', 'css', 'Style name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(334, 'en-gb', 'css_name_required', 'css', 'Please provide a name for your style.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(335, 'en-gb', 'css_property_value', 'css', 'Property : Value', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(336, 'en-gb', 'css_save_failed', 'css', 'The style was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(337, 'en-gb', 'css_selector', 'css', 'Selector', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(338, 'en-gb', 'css_updated', 'css', 'Style <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(339, 'en-gb', 'css_used_by_section', 'css', 'Style <strong>{name}</strong> not deleted; used by {count} section(s).', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(340, 'en-gb', 'delete_declaration', 'css', 'Delete this declaration', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(341, 'en-gb', 'delete_entire_selector', 'css', 'Delete entire selector', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(342, 'en-gb', 'delete_this_declaration', 'css', 'Delete this declaration', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(343, 'en-gb', 'edit_css', 'css', 'Styles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(344, 'en-gb', 'edit_css_file', 'css', 'Edit CSS file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(345, 'en-gb', 'edit_css_in_form', 'css', 'Edit in CSS editor', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(346, 'en-gb', 'edit_raw_css', 'css', 'Edit raw CSS', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(347, 'en-gb', 'name_for_this_style', 'css', 'Name for this style', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(348, 'en-gb', 'property', 'css', 'Property', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(349, 'en-gb', 'save_css_as', 'css', 'Save style as:', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(350, 'en-gb', 'save_this_declaration', 'css', 'Save this declaration', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(351, 'en-gb', 'save_this_selector', 'css', 'Save this selector', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(352, 'en-gb', 'selector', 'css', 'Selector', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(353, 'en-gb', 'style_sheet', 'css', 'Style sheet', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(354, 'en-gb', 'style_sheet_saved', 'css', 'Style saved', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(355, 'en-gb', 'you_are_editing_css', 'css', 'You are editing style', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(356, 'en-gb', 'active_plugins', 'diag', 'Active plugins', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(357, 'en-gb', 'all_checks_passed', 'diag', 'All checks passed!', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(358, 'en-gb', 'apache_modules', 'diag', 'Apache modules', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(359, 'en-gb', 'apache_version', 'diag', 'Apache version', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(360, 'en-gb', 'cleanurl_only_apache', 'diag', 'Clean URLs are only supported on Apache, use at your own risk.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(361, 'en-gb', 'clean_url_data_failed', 'diag', 'Clean URL data test failed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(362, 'en-gb', 'clean_url_test_failed', 'diag', 'Clean URL test failed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(363, 'en-gb', 'detail', 'diag', 'Detail', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(364, 'en-gb', 'dev_version_live', 'diag', 'You are running a development version of Textpattern on a live server.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(365, 'en-gb', 'diagnostic_info', 'diag', 'Diagnostic info', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(366, 'en-gb', 'dir_not_writable', 'diag', '{dirtype} is not writable', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(367, 'en-gb', 'dns_lookup_fails', 'diag', 'DNS lookup failed', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(368, 'en-gb', 'document_root', 'diag', 'Document root', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(369, 'en-gb', 'file_uploads_disabled', 'diag', 'File uploads are disabled', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(370, 'en-gb', 'gd_info', 'diag', '{version}; supported formats: {supported}.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(371, 'en-gb', 'gd_library', 'diag', 'GD Graphics Library', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(372, 'en-gb', 'high', 'diag', 'High', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(373, 'en-gb', 'htaccess_contents', 'diag', '.htaccess file contents', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(374, 'en-gb', 'htaccess_missing', 'diag', '.htaccess file is missing', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(375, 'en-gb', 'img_dir_read_only', 'diag', 'Image directory is read-only', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(376, 'en-gb', 'is_inaccessible', 'diag', 'is inaccessible', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(377, 'en-gb', 'last_update', 'diag', 'Last update', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(378, 'en-gb', 'low', 'diag', 'Low', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(379, 'en-gb', 'magic_quotes', 'diag', 'Magic quotes', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(380, 'en-gb', 'missing_files', 'diag', 'Missing files', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(381, 'en-gb', 'modified_files', 'diag', 'Some Textpattern files have been modified', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(382, 'en-gb', 'mod_rewrite_missing', 'diag', 'Apache module mod_rewrite is not installed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(383, 'en-gb', 'mysql_table_errors', 'diag', 'The following errors were detected in your MySQL tables', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(384, 'en-gb', 'no_temp_dir', 'diag', 'No temporary directory defined', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(385, 'en-gb', 'old_files', 'diag', 'Some Textpattern files are out of date', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(386, 'en-gb', 'old_placeholder', 'diag', 'Old placeholder file is in the way', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(387, 'en-gb', 'os_version', 'diag', 'Server OS', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(388, 'en-gb', 'path_to_site_inacc', 'diag', '<code>$path_to_site</code> is inaccessible.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(389, 'en-gb', 'php_extensions', 'diag', 'PHP extensions', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(390, 'en-gb', 'php_sapi_mode', 'diag', 'PHP server API', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(391, 'en-gb', 'php_version', 'diag', 'PHP version', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(392, 'en-gb', 'php_version_required', 'diag', 'Textpattern CMS requires at least version {version} of PHP to be installed on your server', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(393, 'en-gb', 'preflight_check', 'diag', 'Pre-flight check', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(394, 'en-gb', 'register_globals', 'diag', 'Register globals', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(395, 'en-gb', 'rfc2616_headers', 'diag', 'RFC 2616 headers', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(396, 'en-gb', 'rfc_2616_headers', 'diag', 'CGI header mode', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(397, 'en-gb', 'server', 'diag', 'Server', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(398, 'en-gb', 'server_time', 'diag', 'Server local time', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(399, 'en-gb', 'site_trailing_slash', 'diag', 'Site URL has a trailing slash', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(400, 'en-gb', 'site_url_mismatch', 'diag', 'Site URL preference might be incorrect', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(401, 'en-gb', 'some_php_functions_disabled', 'diag', 'The following PHP functions (which may be necessary to run Textpattern) are disabled on your server', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(402, 'en-gb', 'still_exists', 'diag', 'still exists', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(403, 'en-gb', 'textpattern_update_available', 'diag', 'New Textpattern CMS version {version} <a href="http://textpattern.com/download" rel="external" title="Go to the Textpattern CMS download area">available for download</a>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(404, 'en-gb', 'tmp_plugin_paths_match', 'diag', 'Temporary directory path and Plugin cache directory path should <strong>not</strong> match.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(405, 'en-gb', 'txp_path', 'diag', 'Textpattern path', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(406, 'en-gb', 'txp_version', 'diag', 'Textpattern version', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(407, 'en-gb', 'warn_register_globals_or_update', 'diag', 'Your version of PHP has known security vulnerabilities. Please turn <code>register_globals</code> off or update to a newer PHP version.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(408, 'en-gb', 'web_domain', 'diag', 'Site URL', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(409, 'en-gb', 'article_deleted', 'discuss', 'Article deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(410, 'en-gb', 'ban', 'discuss', 'Ban', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(411, 'en-gb', 'banned_for', 'discuss', 'Banned for', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(412, 'en-gb', 'banned_ips', 'discuss', 'Banned IPs', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(413, 'en-gb', 'ban_author', 'discuss', 'Ban comment author', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(414, 'en-gb', 'cant_ban_blank_ip', 'discuss', 'You cannot ban a blank IP address.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(415, 'en-gb', 'comments_deleted', 'discuss', 'Comments deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(416, 'en-gb', 'comments_marked_spam', 'discuss', 'Comments hidden and marked as spam: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(417, 'en-gb', 'comments_marked_unmoderated', 'discuss', 'Comments hidden and marked as unmoderated: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(418, 'en-gb', 'comments_marked_visible', 'discuss', 'Comments made visible: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(419, 'en-gb', 'comment_not_found', 'discuss', 'Comment does not exist, it may have been deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(420, 'en-gb', 'comment_save_failed', 'discuss', 'The comment was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(421, 'en-gb', 'comment_updated', 'discuss', 'Comment <strong>{id}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(422, 'en-gb', 'confirm_comment_deletion', 'discuss', 'confirm comment deletion', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(423, 'en-gb', 'date_banned', 'discuss', 'Date banned', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(424, 'en-gb', 'displayed_comments', 'discuss', 'Displayed comments', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(425, 'en-gb', 'edit_comment', 'discuss', 'Edit comment', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(426, 'en-gb', 'hide_comment', 'discuss', 'Hide comment', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(427, 'en-gb', 'hide_spam', 'discuss', 'Hide (spam)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(428, 'en-gb', 'hide_unmoderated', 'discuss', 'Hide (unmoderated)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(429, 'en-gb', 'ips_banned', 'discuss', 'IP addresses banned from commenting: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(430, 'en-gb', 'ip_already_banned', 'discuss', 'IP address <strong>{ip}</strong> already banned.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(431, 'en-gb', 'ip_banned', 'discuss', 'IP address <strong>{ip}</strong> banned.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(432, 'en-gb', 'ip_ban_removed', 'discuss', 'IP address <strong>{ip}</strong> ban removed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(433, 'en-gb', 'just_spam_results_found', 'discuss', 'Only spam comments found. Use â€˜Show spamâ€™ to view them.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(434, 'en-gb', 'list_banned_ips', 'discuss', 'List banned IPs', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(435, 'en-gb', 'list_discussions', 'discuss', 'Comments', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(436, 'en-gb', 'name_used', 'discuss', 'Name used', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(437, 'en-gb', 'no_comments_recorded', 'discuss', 'No comments recorded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(438, 'en-gb', 'no_ips_banned', 'discuss', 'No IP addresses have been banned.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(439, 'en-gb', 'show', 'discuss', 'Show', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(440, 'en-gb', 'show_spam', 'discuss', 'Show spam', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(441, 'en-gb', 'unban', 'discuss', 'Unban', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(442, 'en-gb', 'condition', 'file', 'Condition', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(443, 'en-gb', 'download', 'file', 'Download', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(444, 'en-gb', 'downloads', 'file', 'Downloads', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(445, 'en-gb', 'edit_file', 'file', 'Edit file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(446, 'en-gb', 'existing_file', 'file', 'Existing file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(447, 'en-gb', 'file', 'file', 'File', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(448, 'en-gb', 'file_already_exists', 'file', 'File <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(449, 'en-gb', 'file_cannot_rename', 'file', 'File <strong>{name}</strong> could not be renamed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(450, 'en-gb', 'file_category', 'file', 'Category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(451, 'en-gb', 'file_deleted', 'file', 'File(s) <strong>{name}</strong> deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(452, 'en-gb', 'file_delete_failed', 'file', 'Failed to delete file(s)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(453, 'en-gb', 'file_dir_not_writeable', 'file', '<strong>Warning:</strong> cannot write to file directory <code>{filedir}</code>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(454, 'en-gb', 'file_download_count', 'file', 'Download count', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(455, 'en-gb', 'file_name', 'file', 'Name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(456, 'en-gb', 'file_not_found', 'file', 'File(s) not found', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(457, 'en-gb', 'file_not_updated', 'file', 'File <strong>{name}</strong> not updated!', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(458, 'en-gb', 'file_relink', 'file', 'Upload/assign file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(459, 'en-gb', 'file_status', 'file', 'File status', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(460, 'en-gb', 'file_status_missing', 'file', 'Missing', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(461, 'en-gb', 'file_status_ok', 'file', 'OK', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(462, 'en-gb', 'file_unsynchronized', 'file', 'File <strong>{name}</strong> has become unsynchronized with the database. Please manually fix file name.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(463, 'en-gb', 'file_updated', 'file', 'File <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(464, 'en-gb', 'file_uploaded', 'file', 'File <strong>{name}</strong> uploaded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(465, 'en-gb', 'file_upload_failed', 'file', 'Failed to upload file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(466, 'en-gb', 'invalid_filename', 'file', 'Invalid filename', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(467, 'en-gb', 'invalid_id', 'file', 'Invalid ID', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(468, 'en-gb', 'linked_to_file', 'file', 'Linked record to file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(469, 'en-gb', 'no_files_recorded', 'file', 'No files recorded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(470, 'en-gb', 'permissions', 'file', 'Permissions', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(471, 'en-gb', 'private', 'file', 'Private', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(472, 'en-gb', 'public', 'file', 'Public', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(473, 'en-gb', 'replace_file', 'file', 'Replace file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(474, 'en-gb', 'reset', 'file', 'reset', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(475, 'en-gb', 'reset_download_count', 'file', 'Reset download count', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(476, 'en-gb', 'reset_file_count_failure', 'file', 'Failed to reset file count', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(477, 'en-gb', 'reset_file_count_success', 'file', 'Successfully reset file count', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(478, 'en-gb', 'all_forms', 'form', 'All forms', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(479, 'en-gb', 'changetype', 'form', 'Change type', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(480, 'en-gb', 'create_new_form', 'form', 'Create new form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(481, 'en-gb', 'delete_form_confirmation', 'form', 'confirm form deletion', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(482, 'en-gb', 'edit_forms', 'form', 'Form templates', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(483, 'en-gb', 'forms_deleted', 'form', 'Forms deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(484, 'en-gb', 'form_already_exists', 'form', 'Form <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(485, 'en-gb', 'form_code', 'form', 'Form code', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(486, 'en-gb', 'form_created', 'form', 'Form <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(487, 'en-gb', 'form_name', 'form', 'Form name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(488, 'en-gb', 'form_name_invalid', 'form', 'Form name invalid.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(489, 'en-gb', 'form_save_failed', 'form', 'The form was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(490, 'en-gb', 'form_type', 'form', 'Form type', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(491, 'en-gb', 'form_type_missing', 'form', 'Form type is missing', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(492, 'en-gb', 'form_updated', 'form', 'Form <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(493, 'en-gb', 'list_forms', 'form', 'list forms', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(494, 'en-gb', 'you_are_editing_form', 'form', 'You are editing form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(495, 'en-gb', 'add_magnify_icon', 'image', 'Magnifier', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(496, 'en-gb', 'alt_text', 'image', 'Alternate text', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(497, 'en-gb', 'cannot_write_directory', 'image', 'Cannot write to directory', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(498, 'en-gb', 'choose_either_width_height_or_both', 'image', 'Indicate width, height, or both', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(499, 'en-gb', 'create_thumbnail', 'image', 'Create thumbnail', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(500, 'en-gb', 'edit_image', 'image', 'Edit image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(501, 'en-gb', 'images', 'image', 'Images', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(502, 'en-gb', 'image_deleted', 'image', 'Image(s) <strong>{name}</strong> deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(503, 'en-gb', 'image_delete_failed', 'image', 'Image(s) <strong>{name}</strong> could not be completely deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(504, 'en-gb', 'image_name', 'image', 'Image name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(505, 'en-gb', 'image_save_error', 'image', 'There was a problem saving image data.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(506, 'en-gb', 'image_save_failed', 'image', 'The image was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(507, 'en-gb', 'image_updated', 'image', 'Image <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(508, 'en-gb', 'image_uploaded', 'image', 'Image(s) <strong>{name}</strong> uploaded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(509, 'en-gb', 'img_dir_not_writeable', 'image', '<strong>Warning:</strong> cannot write to image directory <code>{imgdir}</code>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(510, 'en-gb', 'invalid_width_or_height', 'image', 'Invalid width or height.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(511, 'en-gb', 'keep_square_pixels', 'image', 'Crop', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(512, 'en-gb', 'not_saved', 'image', '<strong>not</strong> saved!', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(513, 'en-gb', 'no_images_recorded', 'image', 'No images recorded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(514, 'en-gb', 'only_graphic_files_allowed', 'image', 'Only .jpg, .gif, .png or .swf file types allowed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(515, 'en-gb', 'replace_image', 'image', 'Replace image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(516, 'en-gb', 'save_these_settings_as_default', 'image', 'Save settings as default', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(517, 'en-gb', 'thumbnail_deleted', 'image', 'Thumbnail deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(518, 'en-gb', 'thumbnail_not_saved', 'image', 'Thumbnail <strong>{id}</strong> not saved!', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(519, 'en-gb', 'thumbnail_saved', 'image', 'Thumbnail <strong>{id}</strong> saved.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(520, 'en-gb', 'thumb_height', 'image', 'Height', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(521, 'en-gb', 'thumb_width', 'image', 'Width', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(522, 'en-gb', 'upload_category', 'image', 'Category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(523, 'en-gb', 'upload_dir_perms', 'image', 'directory permissions need to be checked.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(524, 'en-gb', 'upload_image', 'image', 'Upload image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(525, 'en-gb', 'upload_thumbnail', 'image', 'Upload thumbnail', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(526, 'en-gb', 'continue', 'import', 'Continue', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(527, 'en-gb', 'database_stuff', 'import', 'Database data', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(528, 'en-gb', 'import_blogid', 'import', 'Blog ID', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(529, 'en-gb', 'import_database', 'import', 'Database name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(530, 'en-gb', 'import_file_not_found', 'import', 'Import file not found. Please name the file <code>import.txt</code> and place it in <code>/textpattern/include/import/</code>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(531, 'en-gb', 'import_host', 'import', 'MySQL host', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(532, 'en-gb', 'import_invite', 'import', 'Default comments invite', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(533, 'en-gb', 'import_login', 'import', 'MySQL user', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(534, 'en-gb', 'import_password', 'import', 'MySQL password', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(535, 'en-gb', 'import_section', 'import', 'Section to import into', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(536, 'en-gb', 'import_status', 'import', 'Default article status', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(537, 'en-gb', 'import_wpdbcharset', 'import', 'Database character set', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(538, 'en-gb', 'import_wpprefix', 'import', 'Tables prefix (if any)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(539, 'en-gb', 'select_tool', 'import', 'Import from', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(540, 'en-gb', 'txp_import', 'import', 'Import content from other publishing tools', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(541, 'en-gb', 'add_new_link', 'link', 'Add new link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(542, 'en-gb', 'edit_link', 'link', 'Edit link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(543, 'en-gb', 'edit_links', 'link', 'Links', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(544, 'en-gb', 'linkcategory', 'link', 'Link categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(545, 'en-gb', 'links', 'link', 'Links', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(546, 'en-gb', 'links_deleted', 'link', 'Link(s) deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(547, 'en-gb', 'linktext', 'link', 'linktext', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(548, 'en-gb', 'link_created', 'link', 'Link <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(549, 'en-gb', 'link_deleted', 'link', 'Link <strong>{name}</strong> deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(550, 'en-gb', 'link_empty', 'link', 'Links should not be empty.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(551, 'en-gb', 'link_name', 'link', 'Name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(552, 'en-gb', 'link_saved', 'link', 'Link saved.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(553, 'en-gb', 'link_save_failed', 'link', 'Link could not be saved.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(554, 'en-gb', 'link_text', 'link', 'Link text', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(555, 'en-gb', 'link_updated', 'link', 'Link(s) <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(556, 'en-gb', 'no_links_recorded', 'link', 'No links recorded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(557, 'en-gb', 'article_modified', 'list', 'Modified', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(558, 'en-gb', 'manage', 'list', 'Manage', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(559, 'en-gb', 'logs', 'log', 'Logs', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(560, 'en-gb', 'logs_deleted', 'log', 'Logs deleted: <strong>{list}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(561, 'en-gb', 'no_refers_recorded', 'log', 'No referrers recorded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(562, 'en-gb', 'referrer', 'log', 'Referrer', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(563, 'en-gb', 'visitor_logs', 'log', 'Visitor logs', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(564, 'en-gb', 'all_pages', 'page', 'All pages', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(565, 'en-gb', 'copy_page_as', 'page', 'â€¦or copy page as', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(566, 'en-gb', 'create_new_page', 'page', 'Create new page', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(567, 'en-gb', 'delete_page_confirmation', 'page', 'confirm page deletion', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(568, 'en-gb', 'edit_page', 'page', 'Edit page', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(569, 'en-gb', 'edit_pages', 'page', 'Page templates', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(570, 'en-gb', 'name_for_this_page', 'page', 'Name for this page', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(571, 'en-gb', 'page_already_exists', 'page', 'Page <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(572, 'en-gb', 'page_article_hed', 'page', 'Article output', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(573, 'en-gb', 'page_article_nav_hed', 'page', 'Article navigation', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(574, 'en-gb', 'page_code', 'page', 'Page code', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(575, 'en-gb', 'page_created', 'page', 'Page <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(576, 'en-gb', 'page_deleted', 'page', 'Page <strong>{name}</strong> deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(577, 'en-gb', 'page_misc_hed', 'page', 'Miscellaneous', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(578, 'en-gb', 'page_name', 'page', 'Page name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(579, 'en-gb', 'page_name_invalid', 'page', 'Page name is invalid.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(580, 'en-gb', 'page_nav_hed', 'page', 'Site navigation', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(581, 'en-gb', 'page_save_failed', 'page', 'The page was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(582, 'en-gb', 'page_updated', 'page', 'Page <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(583, 'en-gb', 'page_used_by_section', 'page', 'Page <strong>{name}</strong> not deleted; used by {count} section(s).', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(584, 'en-gb', 'page_xml_hed', 'page', 'XML feeds', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(585, 'en-gb', 'you_are_editing_div', 'page', 'You are editing div', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(586, 'en-gb', 'you_are_editing_page', 'page', 'You are editing page template', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(587, 'en-gb', 'bad_plugin_code', 'plugin', 'Badly formed or empty plugin code.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(588, 'en-gb', 'broken_plugin', 'plugin', 'broken', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(589, 'en-gb', 'changeorder', 'plugin', 'Change order', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(590, 'en-gb', 'edit_plugin', 'plugin', 'Edit plugin <strong>{name}</strong>', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(591, 'en-gb', 'edit_plugins', 'plugin', 'Edit plugin', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(592, 'en-gb', 'help', 'plugin', 'Help', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(593, 'en-gb', 'install', 'plugin', 'Install', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(594, 'en-gb', 'install_plugin', 'plugin', 'Install plugin', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(595, 'en-gb', 'old_plugin', 'plugin', 'Old-style (text file) plugin installer', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(596, 'en-gb', 'order', 'plugin', 'Order', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(597, 'en-gb', 'plugin', 'plugin', 'Plugin', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(598, 'en-gb', 'plugins', 'plugin', 'Plugins', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(599, 'en-gb', 'plugin_compression_unsupported', 'plugin', 'Plugin decompression is not supported by your server. Contact the plugin author for an uncompressed version.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(600, 'en-gb', 'plugin_deleted', 'plugin', 'Plugin <strong>{name}</strong> deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(601, 'en-gb', 'plugin_help', 'plugin', 'Plugin help', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(602, 'en-gb', 'plugin_installed', 'plugin', 'Plugin <strong>{name}</strong> installed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(603, 'en-gb', 'plugin_install_failed', 'plugin', 'Plugin <strong>{name}</strong> install failed!', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(604, 'en-gb', 'plugin_modified', 'plugin', 'Modified', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(605, 'en-gb', 'plugin_prefs', 'plugin', 'Options', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(606, 'en-gb', 'plugin_saved', 'plugin', 'Plugin <strong>{name}</strong> saved.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(607, 'en-gb', 'plugin_updated', 'plugin', 'Plugin <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(608, 'en-gb', 'previewing_plugin', 'plugin', 'Previewing plugin:', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(609, 'en-gb', 'verify_plugin', 'plugin', 'Verify plugin', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(610, 'en-gb', 'active_language', 'prefs', 'Currently active language', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(611, 'en-gb', 'admin_side_plugins', 'prefs', 'Use admin-side plugins?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(612, 'en-gb', 'advanced_preferences', 'prefs', 'Advanced', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(613, 'en-gb', 'allow_article_php_scripting', 'prefs', 'Allow PHP in articles?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(614, 'en-gb', 'allow_form_override', 'prefs', 'Allow form override?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(615, 'en-gb', 'allow_page_php_scripting', 'prefs', 'Allow PHP in pages?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(616, 'en-gb', 'allow_raw_php_scripting', 'prefs', 'Allow raw PHP?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(617, 'en-gb', 'all_hits', 'prefs', 'All hits', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(618, 'en-gb', 'archive_dateformat', 'prefs', 'Archive date format', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(619, 'en-gb', 'archive_date_case', 'prefs', 'Archive date case', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(620, 'en-gb', 'archive_dir', 'prefs', 'Archive directory', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(621, 'en-gb', 'articles_use_excerpts', 'prefs', 'Articles use excerpts?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(622, 'en-gb', 'attach_titles_to_permalinks', 'prefs', 'Attach titles to permalinks?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(623, 'en-gb', 'auto_dst', 'prefs', 'Automatically adjust <abbr title="Daylight Saving Time">DST</abbr> setting?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(624, 'en-gb', 'category_subcategory', 'prefs', '/category/subcategory', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(625, 'en-gb', 'check_for_txp_updates', 'prefs', 'Check updates', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(626, 'en-gb', 'clean', 'prefs', '/clean/', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(627, 'en-gb', 'comments_are_ol', 'prefs', 'Present comments as a numbered list?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(628, 'en-gb', 'comments_auto_append', 'prefs', 'Automatically append comments to articles?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(629, 'en-gb', 'comments_dateformat', 'prefs', 'Comments date format', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(630, 'en-gb', 'comments_default_invite', 'prefs', 'Default comments invite', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(631, 'en-gb', 'comments_disabled_after', 'prefs', 'Comments disabled after', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(632, 'en-gb', 'comments_disallow_images', 'prefs', 'Strip user images from comments?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(633, 'en-gb', 'comments_mode', 'prefs', 'Comments mode', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(634, 'en-gb', 'comments_moderate', 'prefs', 'Moderate comments?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(635, 'en-gb', 'comments_on_default', 'prefs', 'Comments on by default?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(636, 'en-gb', 'comments_require_email', 'prefs', 'Comments require userâ€™s email address?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(637, 'en-gb', 'comments_require_name', 'prefs', 'Comments require userâ€™s name?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(638, 'en-gb', 'comments_sendmail', 'prefs', 'Email comments to author?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(639, 'en-gb', 'comments_use_fat_textile', 'prefs', 'Allow more Textile markup in comments?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(640, 'en-gb', 'comment_means_site_updated', 'prefs', 'New comment means site updated?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(641, 'en-gb', 'comment_nofollow', 'prefs', 'Apply rel="nofollow" to comments?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(642, 'en-gb', 'convert_linebreaks', 'prefs', 'Convert linebreaks', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(643, 'en-gb', 'css', 'prefs', 'Style', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(644, 'en-gb', 'custom', 'prefs', 'Custom fields', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(645, 'en-gb', 'custom_10_set', 'prefs', 'Custom field 10 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(646, 'en-gb', 'custom_1_set', 'prefs', 'Custom field 1 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(647, 'en-gb', 'custom_2_set', 'prefs', 'Custom field 2 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(648, 'en-gb', 'custom_3_set', 'prefs', 'Custom field 3 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(649, 'en-gb', 'custom_4_set', 'prefs', 'Custom field 4 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(650, 'en-gb', 'custom_5_set', 'prefs', 'Custom field 5 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(651, 'en-gb', 'custom_6_set', 'prefs', 'Custom field 6 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(652, 'en-gb', 'custom_7_set', 'prefs', 'Custom field 7 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(653, 'en-gb', 'custom_8_set', 'prefs', 'Custom field 8 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(654, 'en-gb', 'custom_9_set', 'prefs', 'Custom field 9 name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(655, 'en-gb', 'default_event', 'prefs', 'Default admin tab', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(656, 'en-gb', 'doctype', 'prefs', 'Doctype', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(657, 'en-gb', 'edit_preferences', 'prefs', 'Preferences', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(658, 'en-gb', 'edit_raw_css_by_default', 'prefs', 'Use raw editing mode by default?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(659, 'en-gb', 'enable_xmlrpc_server', 'prefs', 'Enable XML-RPC server?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(660, 'en-gb', 'experts_only', 'prefs', 'experts only', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(661, 'en-gb', 'expire_logs_after', 'prefs', 'Logs expire after how many days?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(662, 'en-gb', 'feeds', 'prefs', 'Feeds', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(663, 'en-gb', 'file_base_path', 'prefs', 'File directory path', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(664, 'en-gb', 'file_max_upload_size', 'prefs', 'Maximum file size of uploads (in bytes)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(665, 'en-gb', 'from_file', 'prefs', 'Install from file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(666, 'en-gb', 'from_server', 'prefs', 'Install from remote server', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(667, 'en-gb', 'gmtoffset', 'prefs', 'Time zone', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(668, 'en-gb', 'ham', 'prefs', 'All but spam', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(669, 'en-gb', 'hours_days_ago', 'prefs', 'hrs/days ago', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(670, 'en-gb', 'id_title', 'prefs', '/id/title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(671, 'en-gb', 'img_dir', 'prefs', 'Image directory', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(672, 'en-gb', 'include_email_atom', 'prefs', 'Include email in Atom feeds?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(673, 'en-gb', 'install_from_textpack', 'prefs', 'Install from Textpack', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(674, 'en-gb', 'install_langfile', 'prefs', 'To install new languages from file you can download them from <code>{url}</code> and place them inside your <code>./textpattern/lang/</code> directory.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(675, 'en-gb', 'install_language', 'prefs', 'Install language', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(676, 'en-gb', 'install_textpack', 'prefs', 'Install Textpack', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(677, 'en-gb', 'is_dst', 'prefs', '<abbr title="Daylight Saving Time">DST</abbr> enabled?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(678, 'en-gb', 'language', 'prefs', 'Language', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(679, 'en-gb', 'lastmod_keepalive', 'prefs', 'Compensate for persistent connection mod_deflate bug?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(680, 'en-gb', 'leave_text_untouched', 'prefs', 'Leave text untouched', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(681, 'en-gb', 'link', 'prefs', 'Links', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(682, 'en-gb', 'locale', 'prefs', 'Locale', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(683, 'en-gb', 'logging', 'prefs', 'Logging', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(684, 'en-gb', 'logs_expire', 'prefs', 'Logs expire after how many days?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(685, 'en-gb', 'manage_languages', 'prefs', 'Language', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(686, 'en-gb', 'markup_default', 'prefs', 'Default markup', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(687, 'en-gb', 'max_url_len', 'prefs', 'Maximum URL length (in characters)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(688, 'en-gb', 'mentions', 'prefs', 'Mentions', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(689, 'en-gb', 'messy', 'prefs', '?=messy', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(690, 'en-gb', 'never_display_email', 'prefs', 'Hide commenter email address?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(691, 'en-gb', 'new_textpattern_version_available', 'prefs', 'There is a completely new Textpattern CMS version available. Do you want to <a href="http://textpattern.com/download" rel="external" title="Go to the Textpattern website download area">download it</a>?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(692, 'en-gb', 'no_popup', 'prefs', 'current window', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(693, 'en-gb', 'override_emailcharset', 'prefs', 'Use ISO-8859-1 encoding in emails (default is UTF-8)?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(694, 'en-gb', 'path_from_root', 'prefs', 'Sub-directory (if any)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(695, 'en-gb', 'path_to_site_missing', 'prefs', '<code>$path_to_site</code> is not set (update <code>index.php</code>)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(696, 'en-gb', 'permalink_title_format', 'prefs', 'Permalink title-like-this (instead of TitleLikeThis)?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(697, 'en-gb', 'permlink_mode', 'prefs', 'Permanent link mode', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(698, 'en-gb', 'ping_textpattern_com', 'prefs', 'Ping textpattern.com?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(699, 'en-gb', 'ping_weblogsdotcom', 'prefs', 'Ping pingomatic.com?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(700, 'en-gb', 'plugin_cache_dir', 'prefs', 'Plugin cache directory path', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(701, 'en-gb', 'preferences_saved', 'prefs', 'Preferences saved', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(702, 'en-gb', 'prefs', 'prefs', 'Prefs', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(703, 'en-gb', 'problem_connecting_rpc_server', 'prefs', 'There is a problem trying to connect to the RPC server. Please, try again later.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(704, 'en-gb', 'production_debug', 'prefs', 'Debugging', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(705, 'en-gb', 'production_live', 'prefs', 'Live', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(706, 'en-gb', 'production_status', 'prefs', 'Production status', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(707, 'en-gb', 'production_test', 'prefs', 'Testing', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(708, 'en-gb', 'publisher_email', 'prefs', 'Send login details from this email address', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(709, 'en-gb', 'publish_expired_articles', 'prefs', 'Publish expired articles?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(710, 'en-gb', 'record_mentions', 'prefs', 'Record mentions', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(711, 'en-gb', 'referrers_only', 'prefs', 'Referrers only', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(712, 'en-gb', 'remove_lang', 'prefs', 'Remove language', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(713, 'en-gb', 'rpc_connect_error', 'prefs', 'Canâ€™t connect to remote server to check for updated language files. Please try again later.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(714, 'en-gb', 'rss_how_many', 'prefs', 'How many articles should be included in feeds?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(715, 'en-gb', 'section_id_title', 'prefs', '/section/id/title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(716, 'en-gb', 'section_title', 'prefs', '/section/title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(717, 'en-gb', 'send_lastmod', 'prefs', 'Send "Last-Modified" header?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(718, 'en-gb', 'show_article_category_count', 'prefs', 'Show article count on categories tab?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(719, 'en-gb', 'show_comment_count_in_feed', 'prefs', 'Show comment count in feeds?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(720, 'en-gb', 'site_prefs', 'prefs', 'Basic', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(721, 'en-gb', 'smtp_from', 'prefs', 'SMTP envelope sender address', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(722, 'en-gb', 'spam_blacklists', 'prefs', 'Spam blocklists (comma-separated)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(723, 'en-gb', 'syndicate_body_or_excerpt', 'prefs', 'Syndicate article excerpt <strong>only</strong>?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(724, 'en-gb', 'tempdir', 'prefs', 'Temporary directory path', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(725, 'en-gb', 'textile_links', 'prefs', 'Textile link descriptions by default?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(726, 'en-gb', 'textpack_strings_installed', 'prefs', '{count} strings installed from Textpack', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(727, 'en-gb', 'theme_name', 'prefs', 'Admin-side theme', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(728, 'en-gb', 'timeoffset', 'prefs', 'Time offset (hours)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(729, 'en-gb', 'title_no_widow', 'prefs', 'Prevent widowed words in article titles?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(730, 'en-gb', 'title_only', 'prefs', '/title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(731, 'en-gb', 'updated', 'prefs', 'Updated', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(732, 'en-gb', 'updated_branch_version_available', 'prefs', 'There is an update for this Textpattern CMS version series available. Do you want to <a href="http://textpattern.com/download" rel="external" title="Go to the Textpattern website download area">download it</a>?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(733, 'en-gb', 'update_languages', 'prefs', 'Update languages', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(734, 'en-gb', 'urls_to_ping', 'prefs', 'URLs to ping (comma-separated)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(735, 'en-gb', 'url_mode', 'prefs', 'URL mode', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(736, 'en-gb', 'use_comments', 'prefs', 'Accept comments?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(737, 'en-gb', 'use_dns', 'prefs', 'Use DNS lookup in visitor logs?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(738, 'en-gb', 'use_mail_on_feeds_id', 'prefs', 'Use email address to construct feed IDs (default is site URL)?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(739, 'en-gb', 'use_plugins', 'prefs', 'Use plugins?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(740, 'en-gb', 'year_month_day_title', 'prefs', '/year/month/day/title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(741, 'en-gb', '403_forbidden', 'public', 'Forbidden.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(742, 'en-gb', '404_not_found', 'public', 'The requested resource was not found.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(743, 'en-gb', '410_gone', 'public', 'The requested resource is no longer available.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(744, 'en-gb', '500_internal_server_error', 'public', 'Internal server error.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(745, 'en-gb', 'ago', 'public', 'ago', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(746, 'en-gb', 'all', 'public', 'All', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(747, 'en-gb', 'already_exists', 'public', 'already exists', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(748, 'en-gb', 'articles', 'public', 'Articles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(749, 'en-gb', 'articles_found', 'public', 'articles found', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(750, 'en-gb', 'article_context', 'public', 'article', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(751, 'en-gb', 'article_found', 'public', 'article found', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(752, 'en-gb', 'atom_feed_title', 'public', 'Atom feed', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(753, 'en-gb', 'attribute_values_must_be_quoted', 'public', 'Attribute values must be quoted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(754, 'en-gb', 'author', 'public', 'Author', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(755, 'en-gb', 'authors', 'public', 'Authors', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(756, 'en-gb', 'a_few_seconds', 'public', 'a few seconds', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(757, 'en-gb', 'back_to_top', 'public', 'â†‘ Back to top', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(758, 'en-gb', 'blockquote', 'public', 'Blockquote', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(759, 'en-gb', 'browse', 'public', 'Browse', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(760, 'en-gb', 'bulleted_list', 'public', 'Bulleted list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(761, 'en-gb', 'caption', 'public', 'Caption', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(762, 'en-gb', 'categories', 'public', 'Categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(763, 'en-gb', 'categorize', 'public', 'Categorise', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(764, 'en-gb', 'category1', 'public', 'Category 1', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(765, 'en-gb', 'category2', 'public', 'Category 2', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(766, 'en-gb', 'change', 'public', 'change', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(767, 'en-gb', 'check_html', 'public', 'Check HTML', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(768, 'en-gb', 'choose', 'public', 'Chooseâ€¦', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(769, 'en-gb', 'citation', 'public', 'citation', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(770, 'en-gb', 'comments', 'public', 'Comments', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(771, 'en-gb', 'comments_closed', 'public', 'Commenting is closed for this article.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(772, 'en-gb', 'comments_on', 'public', 'Comments on', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(773, 'en-gb', 'comments_permlink', 'public', 'Permanent link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(774, 'en-gb', 'comment_comment', 'public', 'Comment', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(775, 'en-gb', 'comment_email', 'public', 'Email', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(776, 'en-gb', 'comment_email_required', 'public', 'Please enter a valid email address.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(777, 'en-gb', 'comment_invitation', 'public', 'Invitation', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(778, 'en-gb', 'comment_message', 'public', 'Message', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(779, 'en-gb', 'comment_moderated', 'public', 'Your comment is pending moderation. It will appear after it has been approved.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(780, 'en-gb', 'comment_name', 'public', 'Name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(781, 'en-gb', 'comment_name_required', 'public', 'Please enter your name.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(782, 'en-gb', 'comment_posted', 'public', 'Thank you for adding your comment.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(783, 'en-gb', 'comment_received', 'public', '[{site}] comment received: {title}', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(784, 'en-gb', 'comment_recorded', 'public', 'A comment on your post â€œ{title}â€ was recorded.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(785, 'en-gb', 'comment_required', 'public', 'Please enter a comment.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(786, 'en-gb', 'comment_web', 'public', 'Website', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(787, 'en-gb', 'contact', 'public', 'Contact', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(788, 'en-gb', 'copy', 'public', 'Copy', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(789, 'en-gb', 'create', 'public', 'Create', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(790, 'en-gb', 'created', 'public', 'created', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(791, 'en-gb', 'create_new', 'public', 'Create new', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(792, 'en-gb', 'date', 'public', 'Date', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(793, 'en-gb', 'dateformat', 'public', 'Date format', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(794, 'en-gb', 'date_case', 'public', 'Date case', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(795, 'en-gb', 'day', 'public', 'day', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(796, 'en-gb', 'days', 'public', 'days', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(797, 'en-gb', 'default', 'public', 'Default', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(798, 'en-gb', 'definition_list', 'public', 'Definition list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(799, 'en-gb', 'delete', 'public', 'Delete', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(800, 'en-gb', 'deleted', 'public', 'deleted', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(801, 'en-gb', 'deleted_text', 'public', 'deleted text', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(802, 'en-gb', 'deprecated_attribute', 'public', '<strong>{name}</strong> attribute is deprecated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(803, 'en-gb', 'deprecated_configuration', 'public', 'Deprecated configuration option: <strong>{name}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(804, 'en-gb', 'deprecated_function', 'public', 'Function <strong>{name}</strong> is deprecated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(805, 'en-gb', 'deprecated_function_with', 'public', 'Function <strong>{name}</strong> is deprecated: use <strong>{with}</strong> instead.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(806, 'en-gb', 'deprecated_tag', 'public', 'tag is deprecated', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(807, 'en-gb', 'download_count', 'public', 'Download count', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(808, 'en-gb', 'edit', 'public', 'Edit', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(809, 'en-gb', 'email', 'public', 'Email', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(810, 'en-gb', 'email_address', 'public', 'Email address', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(811, 'en-gb', 'emphasis', 'public', 'emphasis', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(812, 'en-gb', 'enter_comment_here', 'public', '<strong>Enter your comment below.</strong> Fields marked <b class="required" title="Required">*</b> are required. You must preview your comment first before finally posting.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(813, 'en-gb', 'error_article_context', 'public', 'Article tags cannot be used outside an article context.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(814, 'en-gb', 'error_category_context', 'public', 'Category tags cannot be used outside a category context.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(815, 'en-gb', 'error_comment_context', 'public', 'Comment tags cannot be used outside a comment context.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(816, 'en-gb', 'error_file_context', 'public', 'File tags cannot be used outside a file context.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(817, 'en-gb', 'error_image_context', 'public', 'Image tags cannot be used outside an image context.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(818, 'en-gb', 'error_link_context', 'public', 'Link tags cannot be used outside a link context.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(819, 'en-gb', 'error_section_context', 'public', 'Section tags cannot be used outside a section context.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(820, 'en-gb', 'exact', 'public', 'Exact', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(821, 'en-gb', 'extensions', 'public', 'Extensions', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(822, 'en-gb', 'file_context', 'public', 'file', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(823, 'en-gb', 'file_size', 'public', 'File size', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(824, 'en-gb', 'forget', 'public', 'Forget', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(825, 'en-gb', 'form', 'public', 'Form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(826, 'en-gb', 'forms', 'public', 'Forms', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(827, 'en-gb', 'go', 'public', 'Go', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(828, 'en-gb', 'go_content', 'public', 'Go to content', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(829, 'en-gb', 'go_nav', 'public', 'Go to navigation', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(830, 'en-gb', 'go_search', 'public', 'Go to search', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(831, 'en-gb', 'go_to', 'public', 'Go to', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(832, 'en-gb', 'go_txp_com', 'public', 'Go to the Textpattern website', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(833, 'en-gb', 'header', 'public', 'Heading', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(834, 'en-gb', 'home', 'public', 'Home', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(835, 'en-gb', 'host', 'public', 'Host', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(836, 'en-gb', 'hour', 'public', 'hour', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(837, 'en-gb', 'hours', 'public', 'hours', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(838, 'en-gb', 'hr', 'public', 'horizontal rule', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(839, 'en-gb', 'hyperlink', 'public', 'hyperlink', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(840, 'en-gb', 'image', 'public', 'image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(841, 'en-gb', 'imageurl', 'public', 'imageurl', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(842, 'en-gb', 'image_context', 'public', 'image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(843, 'en-gb', 'inserted_text', 'public', 'inserted text', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(844, 'en-gb', 'invalid_attribute_value', 'public', '<strong>{name}</strong> is not a valid attribute value.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(845, 'en-gb', 'keywords', 'public', 'Keywords', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(846, 'en-gb', 'label', 'public', 'Label', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(847, 'en-gb', 'last_modification', 'public', 'Last modification', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(848, 'en-gb', 'linebreak', 'public', 'line break', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(849, 'en-gb', 'link_context', 'public', 'link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(850, 'en-gb', 'list', 'public', 'List', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(851, 'en-gb', 'list_articles', 'public', 'List articles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(852, 'en-gb', 'list_categories', 'public', 'list categories', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(853, 'en-gb', 'list_links', 'public', 'list links', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(854, 'en-gb', 'live', 'public', 'Live', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(855, 'en-gb', 'lowercase', 'public', 'lowercase', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(856, 'en-gb', 'main_content', 'public', 'Main content', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(857, 'en-gb', 'manual', 'public', 'Manual', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(858, 'en-gb', 'matching_search_request', 'public', 'matching your search request', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(859, 'en-gb', 'message', 'public', 'Message', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(860, 'en-gb', 'message_deleted', 'public', 'Message deleted', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(861, 'en-gb', 'message_preview', 'public', 'Message preview', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(862, 'en-gb', 'message_saved', 'public', 'Message saved', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(863, 'en-gb', 'minute', 'public', 'minute', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(864, 'en-gb', 'minutes', 'public', 'minutes', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(865, 'en-gb', 'missing_article_tag', 'public', 'Page template <strong>{page}</strong> does not contain a txp:article tag.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(866, 'en-gb', 'modified_by', 'public', 'Last modified by', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(867, 'en-gb', 'month', 'public', 'Month', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(868, 'en-gb', 'more', 'public', 'More', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(869, 'en-gb', 'name', 'public', 'Name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(870, 'en-gb', 'never', 'public', 'never', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(871, 'en-gb', 'newer', 'public', 'Newer', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(872, 'en-gb', 'next', 'public', 'Next â†’', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(873, 'en-gb', 'no', 'public', 'No', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(874, 'en-gb', 'none', 'public', 'None', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(875, 'en-gb', 'nopopup', 'public', 'nopopup', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(876, 'en-gb', 'no_comments', 'public', 'There are currently no comments on this article.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(877, 'en-gb', 'no_search_matches', 'public', 'Sorry, no results found matching your search request', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(878, 'en-gb', 'numeric_list', 'public', 'Numeric list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(879, 'en-gb', 'off', 'public', 'Off', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(880, 'en-gb', 'older', 'public', 'Older', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(881, 'en-gb', 'on', 'public', 'On', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(882, 'en-gb', 'only_articles_can_be_previewed', 'public', '<strong>Note:</strong> only article forms can be previewed.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(883, 'en-gb', 'page', 'public', 'Page', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(884, 'en-gb', 'pages', 'public', 'Pages', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(885, 'en-gb', 'paragraph', 'public', 'paragraph', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(886, 'en-gb', 'permanent_link', 'public', 'Permanent link to this article', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(887, 'en-gb', 'permlink', 'public', 'Permanent link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(888, 'en-gb', 'plugin_load_error', 'public', 'A problem occured while loading the plugin:', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(889, 'en-gb', 'plugin_load_error_above', 'public', 'The above errors were caused by the plugin:', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(890, 'en-gb', 'popup', 'public', 'popup', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(891, 'en-gb', 'post', 'public', 'Post', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(892, 'en-gb', 'posted', 'public', 'Posted', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(893, 'en-gb', 'posted_by', 'public', 'Posted by', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(894, 'en-gb', 'press_preview_then_submit', 'public', 'The following is a preview of what your comment will look like. Please do not forget to scroll down and actually press the <strong><a href="#txpCommentSubmit" title="Go to the submit button">submit</a></strong> button!', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(895, 'en-gb', 'prev', 'public', 'â† Prev', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(896, 'en-gb', 'preview', 'public', 'Preview', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(897, 'en-gb', 'publish', 'public', 'Publish', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(898, 'en-gb', 'published_at', 'public', 'Published at', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(899, 'en-gb', 'raw_php_deprecated', 'public', 'Raw PHP tags are deprecated', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(900, 'en-gb', 'recently', 'public', 'Recently', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(901, 'en-gb', 'recent_articles', 'public', 'Recent articles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(902, 'en-gb', 'recent_posts', 'public', 'Recent posts', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(903, 'en-gb', 'remember', 'public', 'Remember', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(904, 'en-gb', 'required', 'public', 'Required', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(905, 'en-gb', 'revert', 'public', 'Revert', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(906, 'en-gb', 'rss_feed_title', 'public', 'RSS feed', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(907, 'en-gb', 'save', 'public', 'Save', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(908, 'en-gb', 'saved', 'public', 'saved', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(909, 'en-gb', 'save_button', 'public', 'Save', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(910, 'en-gb', 'search', 'public', 'Search', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(911, 'en-gb', 'search_results', 'public', 'Search results', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(912, 'en-gb', 'select', 'public', 'Select', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(913, 'en-gb', 'selected', 'public', 'Selected', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(914, 'en-gb', 'site', 'public', 'Site', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(915, 'en-gb', 'sitename', 'public', 'Site name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(916, 'en-gb', 'siteurl', 'public', 'Site URL', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(917, 'en-gb', 'skip_to_main_content', 'public', 'Skip to main content', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(918, 'en-gb', 'status', 'public', 'Status', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(919, 'en-gb', 'strong', 'public', 'strong', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(920, 'en-gb', 'submit', 'public', 'Submit', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(921, 'en-gb', 'subscript', 'public', 'subscript', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(922, 'en-gb', 'superscript', 'public', 'superscript', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(923, 'en-gb', 'tag_error', 'public', 'Tag error:', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(924, 'en-gb', 'textile_help', 'public', 'Textile help', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(925, 'en-gb', 'textile_lite_help', 'public', 'Textile Lite help', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(926, 'en-gb', 'text_conversion', 'public', 'Text conversion', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(927, 'en-gb', 'text_handling', 'public', 'Text handling', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(928, 'en-gb', 'time', 'public', 'Time', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(929, 'en-gb', 'time_ago', 'public', '{time} ago', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(930, 'en-gb', 'title', 'public', 'Title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(931, 'en-gb', 'tooltip', 'public', 'Link tooltip', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(932, 'en-gb', 'too_common_search_term', 'public', 'It seems like you are looking for a very common search term, maybe try a more specific phrase than', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(933, 'en-gb', 'type', 'public', 'Type', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(934, 'en-gb', 'undefined', 'public', 'Undefined', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(935, 'en-gb', 'unknown_attribute', 'public', 'Unknown tag attribute: {att}.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(936, 'en-gb', 'unknown_callback_function', 'public', 'Unknown callback function: {function}.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(937, 'en-gb', 'unknown_image', 'public', 'Unknown image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(938, 'en-gb', 'unknown_section', 'public', 'Unknown section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(939, 'en-gb', 'unknown_tag', 'public', 'tag does not exist', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(940, 'en-gb', 'untitled', 'public', 'Untitled', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(941, 'en-gb', 'update', 'public', 'Update', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(942, 'en-gb', 'upload', 'public', 'Upload', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(943, 'en-gb', 'uploaded', 'public', 'uploaded', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(944, 'en-gb', 'url', 'public', 'URL', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(945, 'en-gb', 'value', 'public', 'Value', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(946, 'en-gb', 'version', 'public', 'Version', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(947, 'en-gb', 'view', 'public', 'View', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(948, 'en-gb', 'website', 'public', 'Website', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(949, 'en-gb', 'week', 'public', 'week', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(950, 'en-gb', 'weeks', 'public', 'weeks', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(951, 'en-gb', 'while_parsing_page_form', 'public', 'while parsing form <strong>{form}</strong> on page <strong>{page}</strong>', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(952, 'en-gb', 'yes', 'public', 'Yes', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(953, 'en-gb', 'your_branch_is_updated', 'public', 'You have the most up-to-date version of this Textpattern branch.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(954, 'en-gb', 'your_ip_is_blacklisted_by', 'public', 'Your IP address has been blocklisted by', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(955, 'en-gb', 'you_have_been_banned', 'public', 'You have been banned from commenting.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(956, 'en-gb', 'yyyy-mm', 'public', 'yyyy-mm', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(957, 'en-gb', 'article_count', 'section', 'Articles in this section: <strong>{num}</strong>.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(958, 'en-gb', 'create_section', 'section', 'Create section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(959, 'en-gb', 'default_write_section', 'section', 'Default publishing section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(960, 'en-gb', 'delete_section_confirmation', 'section', 'confirm section deletion', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(961, 'en-gb', 'edit_default_section', 'section', 'Edit default section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(962, 'en-gb', 'edit_section', 'section', 'Edit section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(963, 'en-gb', 'edit_sections', 'section', 'edit sections', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(964, 'en-gb', 'include_in_search', 'section', 'Include this section in site search?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(965, 'en-gb', 'on_front_page', 'section', 'Section appears on front page?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(966, 'en-gb', 'section', 'section', 'Section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(967, 'en-gb', 'sections', 'section', 'Sections', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(968, 'en-gb', 'section_created', 'section', 'Section <strong>{name}</strong> created.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(969, 'en-gb', 'section_deleted', 'section', 'Section <strong>{name}</strong> deleted.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(970, 'en-gb', 'section_head', 'section', 'Site sections', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(971, 'en-gb', 'section_longtitle', 'section', 'Section title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(972, 'en-gb', 'section_name', 'section', 'Section name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(973, 'en-gb', 'section_name_already_exists', 'section', 'Section <strong>{name}</strong> already exists.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(974, 'en-gb', 'section_save_failed', 'section', 'The section was not saved due to an error. Please try again.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(975, 'en-gb', 'section_updated', 'section', 'Section(s) <strong>{name}</strong> updated.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(976, 'en-gb', 'section_used_by_article', 'section', 'Section <strong>{name}</strong> not deleted; used by {count} article(s).', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(977, 'en-gb', 'selected_by_default', 'section', 'Selected by default', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(978, 'en-gb', 'style', 'section', 'Style', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(979, 'en-gb', 'syndicate', 'section', 'Syndicate articles in this section?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(980, 'en-gb', 'uses_page', 'section', 'Uses page', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(981, 'en-gb', 'uses_style', 'section', 'Uses style', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(982, 'en-gb', 'active_class', 'tag', 'CSS class for active list item', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(983, 'en-gb', 'align', 'tag', 'Alignment', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(984, 'en-gb', 'allowoverride', 'tag', 'Allow form to be overridden?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(985, 'en-gb', 'article_divider', 'tag', 'Article divider', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(986, 'en-gb', 'breadcrumb_linked', 'tag', 'Link breadcrumbs?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(987, 'en-gb', 'breadcrumb_separator', 'tag', 'Breadcrumbs separator', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(988, 'en-gb', 'break', 'tag', 'List break tag', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(989, 'en-gb', 'breakclass', 'tag', 'CSS class for list break tag', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(990, 'en-gb', 'build', 'tag', 'Build tag', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(991, 'en-gb', 'button_text', 'tag', 'Button text', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(992, 'en-gb', 'category_list_section', 'tag', 'Link to specific section?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(993, 'en-gb', 'category_tags', 'tag', 'Category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(994, 'en-gb', 'class', 'tag', 'CSS class', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(995, 'en-gb', 'comments_form', 'tag', 'Comments form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(996, 'en-gb', 'comment_details', 'tag', 'Comment details', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(997, 'en-gb', 'comment_form', 'tag', 'Comment form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(998, 'en-gb', 'comment_name_link', 'tag', 'Link to commenterâ€™s email address/website?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(999, 'en-gb', 'decimals', 'tag', 'Display # numbers after the decimal point', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1000, 'en-gb', 'default_title', 'tag', 'Text to use for default section link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1001, 'en-gb', 'escape', 'tag', 'Escape', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1002, 'en-gb', 'exclude', 'tag', 'Exclude', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1003, 'en-gb', 'filename', 'tag', 'Name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1004, 'en-gb', 'file_download_tags', 'tag', 'File downloads', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1005, 'en-gb', 'flavor', 'tag', 'Syndication format', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1006, 'en-gb', 'flavour', 'tag', 'Syndication format', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1007, 'en-gb', 'format', 'tag', 'Format', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1008, 'en-gb', 'gmt', 'tag', 'Format according to <abbr title="Greenwich Mean Time">GMT</abbr> time?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1009, 'en-gb', 'has_excerpt', 'tag', 'Has excerpt', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1010, 'en-gb', 'hilight', 'tag', 'Highlight tag', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1011, 'en-gb', 'hilight_limit', 'tag', 'Highlight how many instances?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1012, 'en-gb', 'html_id', 'tag', 'ID HTML attribute', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1013, 'en-gb', 'id', 'tag', 'ID#', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1014, 'en-gb', 'include_default', 'tag', 'Include default section?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1015, 'en-gb', 'inline_style', 'tag', 'Inline style (CSS)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1016, 'en-gb', 'input_size', 'tag', 'Input size', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1017, 'en-gb', 'isize', 'tag', 'Input size', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1018, 'en-gb', 'labeltag', 'tag', 'Label tag', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1019, 'en-gb', 'limit', 'tag', 'Display how many?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1020, 'en-gb', 'linkclass', 'tag', 'CSS class for links', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1021, 'en-gb', 'link_to_this_author', 'tag', 'Link to a list of other articles by this author?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1022, 'en-gb', 'link_to_this_category', 'tag', 'Link to a list of other articles in this category?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1023, 'en-gb', 'link_to_this_section', 'tag', 'Link to a list of other articles in this section?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1024, 'en-gb', 'listform', 'tag', 'List form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1025, 'en-gb', 'match', 'tag', 'How are they related?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1026, 'en-gb', 'match_type', 'tag', 'Match type', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1027, 'en-gb', 'media', 'tag', 'Media HTML attribute', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1028, 'en-gb', 'msgcols', 'tag', 'Message textarea columns', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1029, 'en-gb', 'msgrows', 'tag', 'Message textarea rows', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1030, 'en-gb', 'n', 'tag', 'Name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1031, 'en-gb', 'next_page_link', 'tag', 'Next page link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1032, 'en-gb', 'no_categories_available', 'tag', 'No categories available.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1033, 'en-gb', 'no_forms_available', 'tag', 'No forms available.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1034, 'en-gb', 'no_sections_available', 'tag', 'No sections available.', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1035, 'en-gb', 'offset', 'tag', 'Skip', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1036, 'en-gb', 'pageby', 'tag', 'Paginate by', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1037, 'en-gb', 'page_file_hed', 'tag', 'File downloads', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1038, 'en-gb', 'pgonly', 'tag', 'Count articles, but show nothing', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1039, 'en-gb', 'random', 'tag', 'Random', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1040, 'en-gb', 'rel', 'tag', 'Rel HTML attribute', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1041, 'en-gb', 'searchall', 'tag', 'Search all sections?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1042, 'en-gb', 'searchsticky', 'tag', 'Search sticky articles?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1043, 'en-gb', 'search_input_form', 'tag', 'Search input', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1044, 'en-gb', 'search_results_form', 'tag', 'Search results', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1045, 'en-gb', 'section_tags', 'tag', 'Section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1046, 'en-gb', 'showalways', 'tag', 'Show always', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1047, 'en-gb', 'showcount', 'tag', 'Show count?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1048, 'en-gb', 'size_format', 'tag', 'Size format', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1049, 'en-gb', 'sort', 'tag', 'Sort by', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1050, 'en-gb', 'sort_by', 'tag', 'Sort by', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1051, 'en-gb', 'sort_direction', 'tag', 'Sort direction', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1052, 'en-gb', 'tag', 'tag', 'Tag', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1053, 'en-gb', 'tagbuilder', 'tag', 'Tag builder', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1054, 'en-gb', 'tags', 'tag', 'Tags', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1055, 'en-gb', 'tag_article', 'tag', 'Articles (single or list)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1056, 'en-gb', 'tag_article_custom', 'tag', 'Articles (custom list)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1057, 'en-gb', 'tag_article_image', 'tag', 'Article image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1058, 'en-gb', 'tag_author', 'tag', 'Author', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1059, 'en-gb', 'tag_body', 'tag', 'Body', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1060, 'en-gb', 'tag_body_excerpt', 'tag', 'Body excerpt', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1061, 'en-gb', 'tag_breadcrumb', 'tag', 'Breadcrumb', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1062, 'en-gb', 'tag_category', 'tag', 'Category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1063, 'en-gb', 'tag_category1', 'tag', 'Category 1', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1064, 'en-gb', 'tag_category2', 'tag', 'Category 2', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1065, 'en-gb', 'tag_category_list', 'tag', 'Category list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1066, 'en-gb', 'tag_comments', 'tag', 'Comments', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1067, 'en-gb', 'tag_comments_form', 'tag', 'Comments form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1068, 'en-gb', 'tag_comments_invite', 'tag', 'Comments invite', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1069, 'en-gb', 'tag_comments_preview', 'tag', 'Comments preview', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1070, 'en-gb', 'tag_comment_anchor', 'tag', 'Comment anchor', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1071, 'en-gb', 'tag_comment_email', 'tag', 'Comment email', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1072, 'en-gb', 'tag_comment_email_input', 'tag', 'Comment email input', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1073, 'en-gb', 'tag_comment_id', 'tag', 'Comment ID', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1074, 'en-gb', 'tag_comment_message', 'tag', 'Comment message', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1075, 'en-gb', 'tag_comment_message_input', 'tag', 'Comment message input', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1076, 'en-gb', 'tag_comment_name', 'tag', 'Comment name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1077, 'en-gb', 'tag_comment_name_input', 'tag', 'Comment name input', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1078, 'en-gb', 'tag_comment_permlink', 'tag', 'Comment permanent link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1079, 'en-gb', 'tag_comment_preview', 'tag', 'Comment preview button', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1080, 'en-gb', 'tag_comment_remember', 'tag', 'Remember details checkbox', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1081, 'en-gb', 'tag_comment_submit', 'tag', 'Comment submit button', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1082, 'en-gb', 'tag_comment_time', 'tag', 'Comment time', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1083, 'en-gb', 'tag_comment_web', 'tag', 'Comment website', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1084, 'en-gb', 'tag_comment_web_input', 'tag', 'Comment web input', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1085, 'en-gb', 'tag_css', 'tag', 'CSS link (head)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1086, 'en-gb', 'tag_email', 'tag', 'Email link (spam-proof)', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1087, 'en-gb', 'tag_excerpt', 'tag', 'Excerpt', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1088, 'en-gb', 'tag_feed_link', 'tag', 'Articles feed link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1089, 'en-gb', 'tag_file_download', 'tag', 'File download', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1090, 'en-gb', 'tag_file_download_category', 'tag', 'File category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1091, 'en-gb', 'tag_file_download_created', 'tag', 'File created time', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1092, 'en-gb', 'tag_file_download_description', 'tag', 'File description', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1093, 'en-gb', 'tag_file_download_downloads', 'tag', 'File download count', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1094, 'en-gb', 'tag_file_download_id', 'tag', 'File ID#', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1095, 'en-gb', 'tag_file_download_link', 'tag', 'File download link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1096, 'en-gb', 'tag_file_download_list', 'tag', 'File download list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1097, 'en-gb', 'tag_file_download_modified', 'tag', 'File modified time', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1098, 'en-gb', 'tag_file_download_name', 'tag', 'File name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1099, 'en-gb', 'tag_file_download_size', 'tag', 'File size', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1100, 'en-gb', 'tag_home', 'tag', 'Home', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1101, 'en-gb', 'tag_if_category', 'tag', 'If category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1102, 'en-gb', 'tag_if_section', 'tag', 'If section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1103, 'en-gb', 'tag_image', 'tag', 'Image', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1104, 'en-gb', 'tag_inline_', 'tag', 'Inline at end', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1105, 'en-gb', 'tag_lang', 'tag', 'Language', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1106, 'en-gb', 'tag_link', 'tag', 'Link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1107, 'en-gb', 'tag_linkdesctitle', 'tag', 'Link, title=description', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1108, 'en-gb', 'tag_linklist', 'tag', 'Links list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1109, 'en-gb', 'tag_link_category', 'tag', 'Link category', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1110, 'en-gb', 'tag_link_date', 'tag', 'Link date', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1111, 'en-gb', 'tag_link_description', 'tag', 'Link description', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1112, 'en-gb', 'tag_link_feed_link', 'tag', 'Links feed link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1113, 'en-gb', 'tag_link_name', 'tag', 'Link name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1114, 'en-gb', 'tag_link_text', 'tag', 'Link name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1115, 'en-gb', 'tag_link_to_home', 'tag', 'Homepage link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1116, 'en-gb', 'tag_link_to_next', 'tag', 'Next article link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1117, 'en-gb', 'tag_link_to_prev', 'tag', 'Previous article link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1118, 'en-gb', 'tag_message', 'tag', 'Message', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1119, 'en-gb', 'tag_name', 'tag', 'Commenter name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1120, 'en-gb', 'tag_newer', 'tag', 'Newer articles link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1121, 'en-gb', 'tag_next_article', 'tag', 'Next article', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1122, 'en-gb', 'tag_next_title', 'tag', 'Next article title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1123, 'en-gb', 'tag_older', 'tag', 'Older articles link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1124, 'en-gb', 'tag_output_form', 'tag', 'Output form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1125, 'en-gb', 'tag_page_title', 'tag', 'Page title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1126, 'en-gb', 'tag_paging_link', 'tag', 'Next page link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1127, 'en-gb', 'tag_password_protect', 'tag', 'Password protection', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1128, 'en-gb', 'tag_permlink', 'tag', 'Permanent link', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1129, 'en-gb', 'tag_popup', 'tag', 'Popup list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1130, 'en-gb', 'tag_posted', 'tag', 'Posted', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1131, 'en-gb', 'tag_prev_article', 'tag', 'Previous article', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1132, 'en-gb', 'tag_prev_title', 'tag', 'Previous article title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1133, 'en-gb', 'tag_recent_articles', 'tag', 'Recent articles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1134, 'en-gb', 'tag_recent_comments', 'tag', 'Recent comments', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1135, 'en-gb', 'tag_related_articles', 'tag', 'Related articles', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1136, 'en-gb', 'tag_search_input', 'tag', 'Search input form', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1137, 'en-gb', 'tag_search_result_date', 'tag', 'Search result date', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1138, 'en-gb', 'tag_search_result_excerpt', 'tag', 'Search result excerpt', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1139, 'en-gb', 'tag_search_result_title', 'tag', 'Search result title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1140, 'en-gb', 'tag_search_result_url', 'tag', 'Search result URL', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1141, 'en-gb', 'tag_section', 'tag', 'Section', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1142, 'en-gb', 'tag_section_list', 'tag', 'Section list', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1143, 'en-gb', 'tag_sitename', 'tag', 'Site name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1144, 'en-gb', 'tag_site_name', 'tag', 'Site name', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1145, 'en-gb', 'tag_site_slogan', 'tag', 'Site slogan', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1146, 'en-gb', 'tag_title', 'tag', 'Title', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1147, 'en-gb', 'tag__inline', 'tag', 'Inline at beginning', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1148, 'en-gb', 'textonly', 'tag', 'Text only?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1149, 'en-gb', 'text_or_tag', 'tag', '* text or tag here *', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1150, 'en-gb', 'this_section', 'tag', 'Link to current section?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1151, 'en-gb', 'time_any', 'tag', 'Any', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1152, 'en-gb', 'time_format', 'tag', 'Time format string', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1153, 'en-gb', 'time_future', 'tag', 'Future', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1154, 'en-gb', 'time_past', 'tag', 'Past', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1155, 'en-gb', 'title_separator', 'tag', 'Individual article and site name separator', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1156, 'en-gb', 'useful_tags', 'tag', 'Useful tags', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1157, 'en-gb', 'use_thumbnail', 'tag', 'Use thumbnail?', NOW());
INSERT INTO `##TPREF##txp_lang` (`id`, `lang`, `name`, `event`, `data`, `lastmod`) VALUES(1158, 'en-gb', 'wraptag', 'tag', 'Wrap tag', NOW());

CREATE TABLE IF NOT EXISTS `##TPREF##txp_link` (
`id` int(6) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category` varchar(64) NOT NULL DEFAULT '',
  `url` text NOT NULL,
  `linkname` varchar(255) NOT NULL DEFAULT '',
  `linksort` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `author` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

INSERT INTO `##TPREF##txp_link` (`id`, `date`, `category`, `url`, `linkname`, `linksort`, `description`, `author`) VALUES(1, '2005-07-20 12:54:26', 'textpattern', 'http://textpattern.com/', 'Textpattern', '10', '', 'admin');
INSERT INTO `##TPREF##txp_link` (`id`, `date`, `category`, `url`, `linkname`, `linksort`, `description`, `author`) VALUES(2, '2005-07-20 12:54:41', 'textpattern', 'http://textpattern.net/', 'User Documentation', '20', '', 'admin');
INSERT INTO `##TPREF##txp_link` (`id`, `date`, `category`, `url`, `linkname`, `linksort`, `description`, `author`) VALUES(3, '2005-07-20 12:55:04', 'textpattern', 'http://textpattern.org/', 'Txp Resources', '30', '', 'admin');
INSERT INTO `##TPREF##txp_link` (`id`, `date`, `category`, `url`, `linkname`, `linksort`, `description`, `author`) VALUES(4, '2012-06-01 08:15:42', 'textpattern', 'http://textpattern.com/@textpattern', '@textpattern', '40', '', 'admin');
INSERT INTO `##TPREF##txp_link` (`id`, `date`, `category`, `url`, `linkname`, `linksort`, `description`, `author`) VALUES(5, '2012-06-01 08:15:42', 'textpattern', 'http://textpattern.com/+', '+Textpattern CMS', '50', '', 'admin');
INSERT INTO `##TPREF##txp_link` (`id`, `date`, `category`, `url`, `linkname`, `linksort`, `description`, `author`) VALUES(6, '2012-06-01 08:15:42', 'textpattern', 'http://textpattern.com/facebook', 'Textpattern Facebook Group ', '60', '', 'admin');

CREATE TABLE IF NOT EXISTS `##TPREF##txp_log` (
`id` int(12) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `host` varchar(255) NOT NULL DEFAULT '',
  `page` varchar(255) NOT NULL DEFAULT '',
  `refer` mediumtext NOT NULL,
  `status` int(11) NOT NULL DEFAULT '200',
  `method` varchar(16) NOT NULL DEFAULT 'GET',
  `ip` varchar(45) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=##CHARSET##;

CREATE TABLE IF NOT EXISTS `##TPREF##txp_page` (
  `name` varchar(128) NOT NULL DEFAULT '',
  `user_html` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

INSERT INTO `##TPREF##txp_page` (`name`, `user_html`) VALUES('archive', '<!DOCTYPE html>\n<html lang="<txp:lang />">\n\n<head>\n  <meta charset="utf-8">\n  <title><txp:page_title /></title>\n  <meta name="description" content="">\n  <meta name="generator" content="Textpattern CMS">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <meta name="robots" content="noindex, follow, noodp, noydir">\n\n  <txp:if_individual_article>\n    <!-- add meta author for individual articles -->\n    <txp:meta_author title="1" />\n  </txp:if_individual_article>\n\n  <!-- content feeds -->\n  <txp:feed_link flavor="atom" format="link" label="Atom" />\n  <txp:feed_link flavor="rss" format="link" label="RSS" />\n  <txp:rsd />\n\n  <!-- specify canonical, more info: http://googlewebmastercentral.blogspot.com/2009/02/specify-your-canonical.html -->\n  <txp:if_individual_article>\n    <link rel="canonical" href="<txp:permlink />">\n  <txp:else />\n    <link rel="canonical" href="<txp:section url=''1'' />">\n  </txp:if_individual_article>\n\n  <!-- CSS -->\n  <!-- Google font API (remove this if you intend to use the theme in a project without internet access) -->\n  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Serif:n4,i4,n7,i7|Cousine">\n\n  <txp:css format="link" media="" />\n  <!-- ...or you can use (faster) external CSS files eg. <link rel="stylesheet" href="<txp:site_url />css/default.css"> -->\n\n  <!-- HTML5/Media Queries support for IE 8 (you can remove this section and the corresponding ''js'' directory files if you don''t intend to support IE < 9) -->\n  <!--[if lt IE 9]>\n    <script src="<txp:site_url />js/html5shiv.js"></script>\n    <script src="<txp:site_url />js/css3-mediaqueries.js"></script>\n  <![endif]-->\n\n</head>\n\n<body id="<txp:section />-page">\n\n  <!-- header -->\n  <header role="banner">\n    <hgroup>\n      <h1><txp:link_to_home><txp:site_name /></txp:link_to_home></h1>\n      <h3><txp:site_slogan /></h3>\n    </hgroup>\n  </header>\n\n  <!-- navigation -->\n  <nav role="navigation">\n    <h1><txp:text item="navigation" /></h1>\n    <txp:section_list default_title=''<txp:text item="home" />'' include_default="1" wraptag="ul" break="">\n      <li<txp:if_section name=''<txp:section />''> class="active"</txp:if_section>>\n        <txp:section title="1" link="1" />\n      </li>\n    </txp:section_list>\n  </nav>\n\n  <div class="wrapper">\n    <div class="container">\n\n      <!-- left (main) column -->\n      <div role="main">\n\n        <txp:if_article_list><h1><txp:section title="1" /></h1></txp:if_article_list>\n\n        <txp:article listform="article_listing" limit="5" />\n        <!-- or if you want to list all articles from all sections instead, then replace txp:article with txp:article_custom -->\n\n        <!-- add pagination links to foot of article/article listings if there are more articles available,\n          this method is more flexibile than using simple txp:link_to_prev/txp:link_to_next or txp:older/txp:newer tags -->\n        <p id="paginator">\n\n        <txp:if_individual_article>\n\n          <txp:variable name="prev" value=''<txp:link_to_prev />'' />\n          <txp:variable name="next" value=''<txp:link_to_next />'' />\n\n          <txp:if_variable name="prev" value="">\n            <span id="paginator-l" class="button disabled">&#8592; <txp:text item="older" /></span>\n          <txp:else />\n            <a id="paginator-l" href="<txp:link_to_prev />" title="<txp:prev_title />" class="button">&#8592; <txp:text item="older" /></a>\n          </txp:if_variable>\n          <txp:if_variable name="next" value="">\n            <span id="paginator-r" class="button disabled"><txp:text item="newer" /> &#8594;</span>\n          <txp:else />\n            <a id="paginator-r" href="<txp:link_to_next />" title="<txp:next_title />" class="button"><txp:text item="newer" /> &#8594;</a>\n          </txp:if_variable>\n\n        <txp:else />\n\n          <txp:variable name="prev" value=''<txp:older />'' />\n          <txp:variable name="next" value=''<txp:newer />'' />\n          <txp:if_variable name="prev" value="">\n            <span id="paginator-l" class="button disabled">&#8592; <txp:text item="older" /></span>\n          <txp:else />\n            <a id="paginator-l" href="<txp:older />" title="<txp:text item=''older'' />" class="button">&#8592; <txp:text item="older" /></a>\n          </txp:if_variable>\n          <txp:if_variable name="next" value="">\n            <span id="paginator-r" class="button disabled"><txp:text item="newer" /> &#8594;</span>\n          <txp:else />\n            <a id="paginator-r" href="<txp:newer />" title="<txp:text item=''newer'' />" class="button"><txp:text item="newer" /> &#8594;</a>\n          </txp:if_variable>\n\n        </txp:if_individual_article>\n\n        </p>\n\n      </div> <!-- /main -->\n\n      <!-- right (complementary) column -->\n      <div role="complementary">\n        <txp:search_input /> <!-- links by default to form: ''search_input.misc.txp'' unless you specify a different form -->\n  \n        <!-- Feed links, default flavor is rss, so we don''t need to specify a flavor on the first feed_link -->\n        <p><txp:feed_link label="RSS" class="feed-rss" /> / <txp:feed_link flavor="atom" label="Atom" class="feed-atom" /></p>\n\n        <h4><txp:text item="external_links" /></h4>\n        <txp:linklist wraptag="ul" break="li" limit="10" /> <!-- links by default to form: ''plainlinks.link.txp'' unless you specify a different form -->\n      </div> <!-- /complementary -->\n\n    </div> <!-- /.container -->\n  </div> <!-- /.wrapper -->\n\n  <!-- footer -->\n  <footer role="contentinfo">\n    <p><small><txp:text item="published_with" /> <a href="http://textpattern.com" rel="external" title="<txp:text item=''go_txp_com'' />">Textpattern CMS</a>.</small></p>\n  </footer>\n\n  <!-- add your own JavaScript here -->\n\n</body>\n</html>\n');
INSERT INTO `##TPREF##txp_page` (`name`, `user_html`) VALUES('default', '<!DOCTYPE html>\n<html lang="<txp:lang />">\n\n<head>\n  <meta charset="utf-8">\n  <title><txp:page_title /></title>\n  <meta name="description" content="">\n  <meta name="generator" content="Textpattern CMS">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <txp:if_search>\n    <meta name="robots" content="none">\n  <txp:else />\n    <txp:if_category>\n      <meta name="robots" content="noindex, follow, noodp, noydir">\n    <txp:else />\n      <txp:if_author>\n        <meta name="robots" content="noindex, follow, noodp, noydir">\n      <txp:else />\n        <meta name="robots" content="index, follow, noodp, noydir">\n      </txp:if_author>\n    </txp:if_category>\n  </txp:if_search>\n\n  <!-- content feeds -->\n  <txp:feed_link flavor="atom" format="link" label="Atom" />\n  <txp:feed_link flavor="rss" format="link" label="RSS" />\n  <txp:rsd />\n\n  <!-- specify canonical, more info: http://googlewebmastercentral.blogspot.com/2009/02/specify-your-canonical.html -->\n  <txp:if_section name="">\n    <link rel="canonical" href="<txp:site_url />">\n  <txp:else />\n    <txp:if_individual_article>\n      <link rel="canonical" href="<txp:permlink />">\n    <txp:else />\n      <link rel="canonical" href="<txp:section url=''1'' />">\n    </txp:if_individual_article>\n  </txp:if_section>\n\n  <!-- CSS -->\n  <!-- Google font API (remove this if you intend to use the theme in a project without internet access) -->\n  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Serif:n4,i4,n7,i7|Cousine">\n\n  <txp:css format="link" media="" />\n  <!-- ...or you can use (faster) external CSS files eg. <link rel="stylesheet" href="<txp:site_url />css/default.css"> -->\n\n  <!-- HTML5/Media Queries support for IE 8 (you can remove this section and the corresponding ''js'' directory files if you don''t intend to support IE < 9) -->\n  <!--[if lt IE 9]>\n    <script src="<txp:site_url />js/html5shiv.js"></script>\n    <script src="<txp:site_url />js/css3-mediaqueries.js"></script>\n  <![endif]-->\n\n</head>\n\n<body id="<txp:if_section name=""><txp:if_search>search<txp:else />front</txp:if_search><txp:else /><txp:section /></txp:if_section>-page">\n\n  <!-- header -->\n  <header role="banner">\n    <hgroup>\n      <h1><txp:link_to_home><txp:site_name /></txp:link_to_home></h1>\n      <h3><txp:site_slogan /></h3>\n    </hgroup>\n  </header>\n\n  <!-- navigation -->\n  <nav role="navigation">\n    <h1><txp:text item="navigation" /></h1>\n    <txp:section_list default_title=''<txp:text item="home" />'' include_default="1" wraptag="ul" break="">\n      <li<txp:if_section name=''<txp:section />''><txp:if_search><txp:else /><txp:if_category><txp:else /><txp:if_author><txp:else /> class="active"</txp:if_author></txp:if_category></txp:if_search></txp:if_section>>\n        <txp:section title="1" link="1" />\n      </li>\n    </txp:section_list>\n  </nav>\n\n  <div class="wrapper">\n    <div class="container">\n\n      <!-- left (main) column -->\n      <div role="main">\n\n      <!-- is this result result page? also omits the pagination links below (uses pagination format within search_results.article.txp instead) -->\n      <txp:if_search>\n\n        <h1><txp:text item="search_results" /></h1>\n        <txp:output_form form="search_results"/>\n\n      <txp:else />\n\n        <!-- else is this an article category list? -->\n        <txp:if_category>\n\n          <h1><txp:text item="category" /> <txp:category title="1" /></h1>\n          <txp:article form="article_listing" limit="5" />\n\n        <txp:else />\n\n          <!-- else is this an article author list? -->\n          <txp:if_author>\n\n          <h1><txp:text item="author" /> <txp:author /></h1>\n          <txp:article form="article_listing" limit="5" />\n\n          <txp:else />\n\n            <!-- else display articles normally -->\n            <txp:article limit="5" /> <!-- links by default to form: ''default.article.txp'' unless you specify a different form -->\n\n          </txp:if_author>\n        </txp:if_category>\n\n        <!-- add pagination links to foot of article/article listings/category listings if there are more articles available,\n          this method is more flexibile than using simple txp:link_to_prev/txp:link_to_next or txp:older/txp:newer tags -->\n        <p id="paginator">\n\n        <txp:variable name="prev" value=''<txp:older />'' />\n        <txp:variable name="next" value=''<txp:newer />'' />\n\n        <txp:if_variable name="prev" value="">\n          <span id="paginator-l" class="button disabled">&#8592; <txp:text item="older" /></span>\n        <txp:else />\n          <a id="paginator-l" href="<txp:older />" title="<txp:text item=''older'' />" class="button">&#8592; <txp:text item="older" /></a>\n        </txp:if_variable>\n        <txp:if_variable name="next" value="">\n          <span id="paginator-r" class="button disabled"><txp:text item="newer" /> &#8594;</span>\n        <txp:else />\n            <a id="paginator-r" href="<txp:newer />" title="<txp:text item=''newer'' />" class="button"><txp:text item="newer" /> &#8594;</a>\n        </txp:if_variable>\n\n        </p>\n\n      </txp:if_search>\n\n      </div> <!-- /main -->\n\n      <!-- right (complementary) column -->\n      <div role="complementary">\n        <txp:search_input /> <!-- links by default to form: ''search_input.misc.txp'' unless you specify a different form -->\n\n        <!-- Feed links, default flavor is rss, so we don''t need to specify a flavor on the first feed_link -->\n        <p><txp:feed_link label="RSS" class="feed-rss" /> / <txp:feed_link flavor="atom" label="Atom" class="feed-atom" /></p>\n\n        <h4><txp:text item="external_links" /></h4>\n        <txp:linklist wraptag="ul" break="li" limit="10" /> <!-- links by default to form: ''plainlinks.link.txp'' unless you specify a different form -->\n      </div> <!-- /complementary -->\n\n    </div> <!-- /.container -->\n  </div> <!-- /.wrapper -->\n\n  <!-- footer -->\n  <footer role="contentinfo">\n    <p><small><txp:text item="published_with" /> <a href="http://textpattern.com" rel="external" title="<txp:text item=''go_txp_com'' />">Textpattern CMS</a>.</small></p>\n  </footer>\n\n  <!-- add your own JavaScript here -->\n\n</body>\n</html>\n');
INSERT INTO `##TPREF##txp_page` (`name`, `user_html`) VALUES('error_default', '<!DOCTYPE html>\n<html lang="<txp:lang />">\n\n<head>\n  <meta charset="utf-8">\n  <title><txp:error_status /></title>\n  <meta name="description" content="<txp:error_message />">\n  <meta name="generator" content="Textpattern CMS">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <meta name="robots" content="none">\n\n  <!-- content feeds -->\n  <txp:feed_link flavor="atom" format="link" label="Atom" />\n  <txp:feed_link flavor="rss" format="link" label="RSS" />\n  <txp:rsd />\n\n  <!-- CSS -->\n  <!-- Google font API (remove this if you intend to use the theme in a project without internet access) -->\n  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Serif:n4,i4,n7,i7|Cousine">\n\n  <txp:css format="link" media="" />\n  <!-- ...or you can use (faster) external CSS files eg. <link rel="stylesheet" href="<txp:site_url />css/default.css"> -->\n\n  <!-- HTML5/Media Queries support for IE 8 (you can remove this section and the corresponding ''js'' directory files if you don''t intend to support IE < 9) -->\n  <!--[if lt IE 9]>\n    <script src="<txp:site_url />js/html5shiv.js"></script>\n    <script src="<txp:site_url />js/css3-mediaqueries.js"></script>\n  <![endif]-->\n\n</head>\n\n<body id="error-page">\n\n  <!-- header -->\n  <header role="banner">\n    <hgroup>\n      <h1><txp:link_to_home><txp:site_name /></txp:link_to_home></h1>\n      <h3><txp:site_slogan /></h3>\n    </hgroup>\n  </header>\n\n  <!-- navigation -->\n  <nav role="navigation">\n    <h1><txp:text item="navigation" /></h1>\n    <txp:section_list default_title=''<txp:text item="home" />'' include_default="1" wraptag="ul" break="li">\n      <txp:section title="1" link="1" />\n    </txp:section_list>\n  </nav>\n\n  <div class="wrapper">\n    <div class="container">\n\n      <!-- left (main) column -->\n      <div role="main">\n        <h1 class="error-status"><txp:error_status /></h1>\n        <p class="error-msg"><txp:error_message /></p>\n      </div> <!-- /main -->\n\n      <!-- right (complementary) column -->\n      <div role="complementary">\n        <txp:search_input /> <!-- links by default to form: ''search_input.misc.txp'' unless you specify a different form -->\n\n        <!-- Feed links, default flavor is rss, so we don''t need to specify a flavor on the first feed_link -->\n        <p><txp:feed_link label="RSS" class="feed-rss" /> / <txp:feed_link flavor="atom" label="Atom" class="feed-atom" /></p>\n\n        <h4><txp:text item="external_links" /></h4>\n        <txp:linklist wraptag="ul" break="li" limit="10" /> <!-- links by default to form: ''plainlinks.link.txp'' unless you specify a different form -->\n      </div> <!-- /complementary -->\n\n    </div> <!-- /.container -->\n  </div> <!-- /.wrapper -->\n\n  <!-- footer -->\n  <footer role="contentinfo">\n    <p><small><txp:text item="published_with" /> <a href="http://textpattern.com" rel="external" title="<txp:text item=''go_txp_com'' />">Textpattern CMS</a>.</small></p>\n  </footer>\n\n  <!-- add your own JavaScript here -->\n\n</body>\n</html>\n');

CREATE TABLE IF NOT EXISTS `##TPREF##txp_plugin` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `status` int(2) NOT NULL DEFAULT '1',
  `author` varchar(128) NOT NULL DEFAULT '',
  `author_uri` varchar(128) NOT NULL DEFAULT '',
  `version` varchar(10) NOT NULL DEFAULT '1.0',
  `description` text NOT NULL,
  `help` text NOT NULL,
  `code` mediumtext NOT NULL,
  `code_restore` mediumtext NOT NULL,
  `code_md5` varchar(32) NOT NULL DEFAULT '',
  `type` int(2) NOT NULL DEFAULT '0',
  `load_order` tinyint(3) unsigned NOT NULL DEFAULT '5',
  `flags` smallint(5) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET##;

CREATE TABLE IF NOT EXISTS `##TPREF##txp_prefs` (
  `prefs_id` int(11) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `val` text NOT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT '2',
  `event` varchar(12) NOT NULL DEFAULT 'publish',
  `html` varchar(64) NOT NULL DEFAULT 'text_input',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(64) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET##;

INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'prefs_id', '1', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'sitename', 'My site', 0, 'publish', 'text_input', 20, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'site_slogan', 'My pithy slogan', 0, 'publish', 'text_input', 30, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'language', 'en-gb', 2, 'publish', 'languages', 40, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'url_mode', '1', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'timeoffset', '0', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_on_default', '0', 0, 'comments', 'yesnoradio', 20, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_default_invite', 'Comment', 0, 'comments', 'text_input', 40, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_mode', '0', 0, 'comments', 'commentmode', 120, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_disabled_after', '42', 0, 'comments', 'weeks', 80, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'use_textile', '1', 0, 'publish', 'pref_text', 200, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'ping_weblogsdotcom', '0', 1, 'publish', 'yesnoradio', 160, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'rss_how_many', '5', 1, 'feeds', 'text_input', 40, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'logging', 'all', 0, 'publish', 'logging', 220, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'use_comments', '1', 0, 'publish', 'yesnoradio', 240, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'use_categories', '1', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'use_sections', '1', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'send_lastmod', '1', 1, 'publish', 'yesnoradio', 120, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'path_from_root', '/', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'lastmod', NOW(), 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_dateformat', '%b %Oe, %I:%M %p', 0, 'comments', 'dateformats', 140, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'dateformat', 'since', 0, 'publish', 'dateformats', 140, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'archive_dateformat', '%b %Oe, %I:%M %p', 0, 'publish', 'dateformats', 160, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_moderate', '1', 0, 'comments', 'yesnoradio', 60, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'img_dir', 'images', 1, 'admin', 'text_input', 20, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_disallow_images', '0', 1, 'comments', 'yesnoradio', 120, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_sendmail', '0', 0, 'comments', 'commentsendmail', 180, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'file_max_upload_size', '2000000', 1, 'admin', 'text_input', 60, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'timezone_key', 'America/New_York', 2, 'publish', 'textinput', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'default_event', 'article', 1, 'admin', 'default_event', 150, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'auto_dst', '0', 0, 'publish', 'yesnoradio', 115, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'permlink_mode', 'section_id_title', 0, 'publish', 'permlinkmodes', 180, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_are_ol', '1', 0, 'comments', 'yesnoradio', 160, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'is_dst', '0', 0, 'publish', 'is_dst', 120, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'locale', 'en_GB.UTF-8', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'blog_time_uid', '2005', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'publisher_email', '', 1, 'admin', 'text_input', 115, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'allow_page_php_scripting', '1', 1, 'publish', 'yesnoradio', 300, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'allow_article_php_scripting', '1', 1, 'publish', 'yesnoradio', 320, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'default_section', 'articles', 2, 'section', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_use_fat_textile', '0', 1, 'comments', 'yesnoradio', 130, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'show_article_category_count', '1', 2, 'category', 'yesnoradio', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'show_comment_count_in_feed', '1', 1, 'feeds', 'yesnoradio', 60, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'syndicate_body_or_excerpt', '1', 1, 'feeds', 'yesnoradio', 20, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'include_email_atom', '1', 1, 'feeds', 'yesnoradio', 80, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comment_means_site_updated', '1', 1, 'comments', 'yesnoradio', 160, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'never_display_email', '0', 1, 'comments', 'yesnoradio', 60, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_require_name', '1', 1, 'comments', 'yesnoradio', 20, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_require_email', '1', 1, 'comments', 'yesnoradio', 40, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'articles_use_excerpts', '1', 1, 'publish', 'yesnoradio', 40, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'allow_form_override', '1', 1, 'publish', 'yesnoradio', 60, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'attach_titles_to_permalinks', '1', 1, 'publish', 'yesnoradio', 80, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'permalink_title_format', '1', 1, 'publish', 'yesnoradio', 100, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'expire_logs_after', '7', 1, 'publish', 'text_input', 200, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'use_plugins', '1', 1, 'publish', 'yesnoradio', 260, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_1_set', 'custom1', 1, 'custom', 'custom_set', 1, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_2_set', 'custom2', 1, 'custom', 'custom_set', 2, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_3_set', '', 1, 'custom', 'custom_set', 3, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_4_set', '', 1, 'custom', 'custom_set', 4, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_5_set', '', 1, 'custom', 'custom_set', 5, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_6_set', '', 1, 'custom', 'custom_set', 6, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_7_set', '', 1, 'custom', 'custom_set', 7, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_8_set', '', 1, 'custom', 'custom_set', 8, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_9_set', '', 1, 'custom', 'custom_set', 9, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'custom_10_set', '', 1, 'custom', 'custom_set', 10, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'ping_textpattern_com', '1', 1, 'publish', 'yesnoradio', 180, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'use_dns', '1', 1, 'publish', 'yesnoradio', 220, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'admin_side_plugins', '1', 1, 'publish', 'yesnoradio', 280, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comment_nofollow', '1', 1, 'comments', 'yesnoradio', 80, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'use_mail_on_feeds_id', '0', 1, 'feeds', 'yesnoradio', 100, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'max_url_len', '200', 1, 'publish', 'text_input', 240, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'spam_blacklists', 'sbl.spamhaus.org', 1, 'comments', 'text_input', 140, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'override_emailcharset', '0', 1, 'admin', 'yesnoradio', 120, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'production_status', 'testing', 0, 'publish', 'prod_levels', 80, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'comments_auto_append', '0', 0, 'comments', 'yesnoradio', 100, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'dbupdatetime', '1418611016', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'version', '4.5.7', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'doctype', 'html5', 0, 'publish', 'doctypes', 190, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'theme_name', 'classic', 1, 'admin', 'themename', 160, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'gmtoffset', '-18000', 0, 'publish', 'gmtoffset_select', 100, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'plugin_cache_dir', '', 1, 'admin', 'text_input', 100, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'textile_updated', '1', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'title_no_widow', '1', 1, 'publish', 'yesnoradio', 20, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'lastmod_keepalive', '0', 1, 'publish', 'yesnoradio', 140, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'enable_xmlrpc_server', '0', 1, 'admin', 'yesnoradio', 130, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'smtp_from', '', 1, 'admin', 'text_input', 110, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'publish_expired_articles', '0', 1, 'publish', 'yesnoradio', 130, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'searchable_article_fields', 'Title, Body', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'last_update_check', 'a:2:{s:3:"msg";s:80:"There is a problem trying to connect to the RPC server. Please, try again later.";s:4:"when";i:1418611027;}', 2, 'publish', 'text_input', 0, '');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'admin_sort_column', 'name', 2, 'admin', '', 0, 'admin');
INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES(1, 'admin_sort_dir', 'asc', 2, 'admin', '', 0, 'admin');

  INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES ('1', 'siteurl', '##REALURL##', '0', 'publish', 'text_input', '40', '');
  INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES ('1', 'path_to_site', '##INSTALL_FOLLDER##', 2, 'publish', 'text_input', 0, '');
  INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES ('1', 'tempdir', '##INSTALL_TMP_FOLLDER##', 1, 'admin', 'text_input', '80', '');
  INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES ('1', 'file_base_path', '##INSTALL_FILES_FOLLDER##', 1, 'admin', 'text_input', '40', '');
  INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES ('1', 'blog_uid', md5(''), '2', 'publish', 'text_input', '0', '');
  INSERT INTO `##TPREF##txp_prefs` (`prefs_id`, `name`, `val`, `type`, `event`, `html`, `position`, `user_name`) VALUES ('1', 'blog_mail_uid', '##ADMIN_EMAIL##', '2', 'publish', 'text_input', '0', '');


CREATE TABLE IF NOT EXISTS `##TPREF##txp_section` (
  `name` varchar(128) NOT NULL DEFAULT '',
  `page` varchar(128) NOT NULL DEFAULT '',
  `css` varchar(128) NOT NULL DEFAULT '',
  `in_rss` int(2) NOT NULL DEFAULT '1',
  `on_frontpage` int(2) NOT NULL DEFAULT '1',
  `searchable` int(2) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

INSERT INTO `##TPREF##txp_section` (`name`, `page`, `css`, `in_rss`, `on_frontpage`, `searchable`, `title`) VALUES('articles', 'archive', 'default', 1, 1, 1, 'Articles');
INSERT INTO `##TPREF##txp_section` (`name`, `page`, `css`, `in_rss`, `on_frontpage`, `searchable`, `title`) VALUES('default', 'default', 'default', 1, 1, 1, 'default');
INSERT INTO `##TPREF##txp_section` (`name`, `page`, `css`, `in_rss`, `on_frontpage`, `searchable`, `title`) VALUES('about', 'default', 'default', 0, 0, 1, 'About');

CREATE TABLE IF NOT EXISTS `##TPREF##txp_users` (
`user_id` int(4) NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(128) NOT NULL,
  `RealName` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(254) NOT NULL DEFAULT '',
  `privs` tinyint(2) NOT NULL DEFAULT '1',
  `last_access` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nonce` varchar(64) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=##CHARSET## PACK_KEYS=1;

  INSERT INTO `##TPREF##txp_users` (`user_id`, `name`, `pass`, `RealName`, `email`, `privs`, `last_access`, `nonce`) VALUES ('1', '##ADMIN_USER##', OLD_PASSWORD('##ADMIN_PASS##'), 'FULL NAME', '##ADMIN_EMAIL##', 1,  NOW(), '');

ALTER TABLE `##TPREF##textpattern`
 ADD PRIMARY KEY (`ID`), ADD KEY `categories_idx` (`Category1`(10),`Category2`(10)), ADD KEY `Posted` (`Posted`), ADD KEY `section_status_idx` (`Section`,`Status`), ADD KEY `Expires_idx` (`Expires`), ADD KEY `author_idx` (`AuthorID`), ADD KEY `url_title_idx` (`url_title`), ADD FULLTEXT KEY `searching` (`Title`,`Body`);

ALTER TABLE `##TPREF##txp_category`
 ADD PRIMARY KEY (`id`);

ALTER TABLE `##TPREF##txp_css`
 ADD UNIQUE KEY `name` (`name`);

ALTER TABLE `##TPREF##txp_discuss`
 ADD PRIMARY KEY (`discussid`), ADD KEY `parentid` (`parentid`);

ALTER TABLE `##TPREF##txp_discuss_ipban`
 ADD PRIMARY KEY (`ip`);

ALTER TABLE `##TPREF##txp_discuss_nonce`
 ADD PRIMARY KEY (`nonce`);

ALTER TABLE `##TPREF##txp_file`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `filename` (`filename`), ADD KEY `author_idx` (`author`);

ALTER TABLE `##TPREF##txp_form`
 ADD PRIMARY KEY (`name`);

ALTER TABLE `##TPREF##txp_image`
 ADD PRIMARY KEY (`id`), ADD KEY `author_idx` (`author`);

ALTER TABLE `##TPREF##txp_lang`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `lang` (`lang`,`name`), ADD KEY `lang_2` (`lang`,`event`);

ALTER TABLE `##TPREF##txp_link`
 ADD PRIMARY KEY (`id`), ADD KEY `author_idx` (`author`);

ALTER TABLE `##TPREF##txp_log`
 ADD PRIMARY KEY (`id`), ADD KEY `time` (`time`), ADD KEY `ip` (`ip`);

ALTER TABLE `##TPREF##txp_page`
 ADD PRIMARY KEY (`name`);

ALTER TABLE `##TPREF##txp_plugin`
 ADD UNIQUE KEY `name` (`name`), ADD KEY `status_type_idx` (`status`,`type`);

ALTER TABLE `##TPREF##txp_prefs`
 ADD UNIQUE KEY `prefs_idx` (`prefs_id`,`name`,`user_name`), ADD KEY `name` (`name`), ADD KEY `user_name` (`user_name`);

ALTER TABLE `##TPREF##txp_section`
 ADD PRIMARY KEY (`name`);

ALTER TABLE `##TPREF##txp_users`
 ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `name` (`name`);


ALTER TABLE `##TPREF##textpattern`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
ALTER TABLE `##TPREF##txp_category`
MODIFY `id` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
ALTER TABLE `##TPREF##txp_discuss`
MODIFY `discussid` int(6) unsigned zerofill NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
ALTER TABLE `##TPREF##txp_file`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `##TPREF##txp_image`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `##TPREF##txp_lang`
MODIFY `id` int(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1159;
ALTER TABLE `##TPREF##txp_link`
MODIFY `id` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
ALTER TABLE `##TPREF##txp_log`
MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=78;
ALTER TABLE `##TPREF##txp_users`
MODIFY `user_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
