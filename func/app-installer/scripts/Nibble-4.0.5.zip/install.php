<?php

/*
 * Nibbleblog -
 * http://www.nibbleblog.com
 * Author Diego Najar

 * All Nibbleblog code is released under the GNU General Public License.
 * See COPYRIGHT.txt and LICENSE.txt.
*/

/*
 * For 1-Click Setup
 * This are the POST variables to install Nibbleblog without the default form.
 * You can delete/replace this file, is independent from the blog, it only for install.
 *
 * $_POST = array('name', 'slogan', 'url', 'path', 'email', 'username', 'password')
 *
 * $_POST['name'] = Blog name
 * $_POST['slogan'] = Blog slogan
 * $_POST['url'] = Complete URL of your blog, example: http://www.mysite.com/blog/
 * $_POST['path'] = Relative directory of your blog on the server, example: /blog/
 * $_POST['email'] = Admin's email
 * $_POST['username'] = Admin's username
 * $_POST['password'] = Admin's password in plain text
 *
*/





// =====================================================================
//	FILES
// =====================================================================
if( file_exists('content/private') || file_exists('content/public') )
	exit('Blog already installed... May be you want to <a href="update.php">update</a> ?');

// Boot
require('admin/boot/rules/1-fs_php.bit');
require('admin/boot/rules/4-remove_magic.bit');
require('admin/boot/rules/98-constants.bit');

// CLASS
require(PATH_DB . 'nbxml.class.php');
require(PATH_DB . 'db_posts.class.php');
require(PATH_KERNEL . 'plugin.class.php');
require(PATH_HELPERS . 'crypt.class.php');
require(PATH_HELPERS . 'date.class.php');
require(PATH_HELPERS . 'filesystem.class.php');
require(PATH_HELPERS . 'html.class.php');
require(PATH_HELPERS . 'net.class.php');
require(PATH_HELPERS . 'number.class.php');
require(PATH_HELPERS . 'redirect.class.php');
require(PATH_HELPERS . 'text.class.php');
require(PATH_HELPERS . 'validation.class.php');
require(PATH_HELPERS . 'session.class.php');

// =====================================================================
//	VARIABLES
// =====================================================================
$permissions_dir = 0755;

$php_modules = array();

$installation_complete = false;

$dependencies = false;

$domain = '##DOMAIN##';

$base_path = '##INSTALL_DIR##';
if($base_path!='/')
	$base_path .='/';

$blog_address = 'http://'.$domain.$base_path;

$languages = array();
$files = Filesystem::ls(PATH_LANGUAGES, '*', 'bit', false, false, false);
foreach($files as $file)
{
	include(PATH_LANGUAGES.$file);
	$iso = basename($file, '.bit');
	$languages[$iso] = $_LANG_CONFIG['DATA']['native'];
}

// ============================================================================
//	SYSTEM
// ============================================================================

// PHP MODULES
if(function_exists('get_loaded_extensions'))
{
	$php_modules = get_loaded_extensions();
}

// WRITING TEST
// Try to give permissions to the directory content
if(!file_exists('content'))
{
	@mkdir('content', $permissions_dir, true);
}
@chmod('content', $permissions_dir);
@rmdir('content/tmp');
$writing_test = @mkdir('content/tmp');

// REGIONAL
if( !@include( 'languages/'. $_GET['language'] . '.bit' ) )
{
	$_GET['language'] = 'en_US';
	require( 'languages/en_US.bit' );
}

Date::set_timezone('UTC');

// ============================================================================
//	POST
// ============================================================================

//if(php_sapi_name() === 'cli' || defined('STDIN')){

$_POST['name'] = 'Blog Name';
$_POST['slogan'] =  'Your new blog slogan.';
$_POST['url'] =  '##SITEURL##';
$_POST['path'] =  '##INSTALL_FOLLDER##';
$_POST['email'] =  '##ADMIN_EMAIL##';
$_POST['username'] =  '##ADMIN_USER##';
$_POST['password'] =  '##ADMIN_PASS##';


	mkdir('content/private',		$permissions_dir, true);
	mkdir('content/private/plugins',$permissions_dir, true);
	mkdir('content/public',			$permissions_dir, true);
	mkdir('content/public/upload',	$permissions_dir, true);
	mkdir('content/public/posts',	$permissions_dir, true);
	mkdir('content/public/pages',	$permissions_dir, true);
	mkdir('content/public/comments',$permissions_dir, true);

	// Config.xml
	$xml  = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
	$xml .= '<config>';
	$xml .= '</config>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);

	// General
	$obj->addChild('name',					$_POST['name']);
	$obj->addChild('slogan',				$_POST['slogan']);
	$obj->addChild('footer',				$_LANG['POWERED_BY_NIBBLEBLOG']);
	$obj->addChild('advanced_post_options', 0);

	// Advanced
	$obj->addChild('url',					$_POST['url']);
	$obj->addChild('path',					$_POST['path']);
	$obj->addChild('items_rss',				4);
	$obj->addChild('items_page',			6);

	// Regional
	$obj->addChild('language',				$_GET['language']);
	$obj->addChild('timezone',				'UTC');
	$obj->addChild('timestamp_format',		'%d %B, %Y');
	$obj->addChild('locale',				$_GET['language']);

	// Images
	$obj->addChild('img_resize',			1);
	$obj->addChild('img_resize_width',		1000);
	$obj->addChild('img_resize_height',		600);
	$obj->addChild('img_resize_quality',	100);
	$obj->addChild('img_resize_option',		'auto');
	$obj->addChild('img_thumbnail',			1);
	$obj->addChild('img_thumbnail_width',	190);
	$obj->addChild('img_thumbnail_height',	190);
	$obj->addChild('img_thumbnail_quality',	100);
	$obj->addChild('img_thumbnail_option',	'landscape');

	// Theme
	$obj->addChild('theme',					'simpler');

	// Notifications
	$obj->addChild('notification_comments',			1);
	$obj->addChild('notification_session_fail',		0);
	$obj->addChild('notification_session_start',	0);
	$obj->addChild('notification_email_to',			$_POST['email']);
	$obj->addChild('notification_email_from',		'noreply@'.$domain);

	// SEO
	$obj->addChild('seo_site_title',		$_POST['name'].' - '.$_POST['slogan']);
	$obj->addChild('seo_site_description',	'');
	$obj->addChild('seo_keywords',			'');
	$obj->addChild('seo_robots',			'');
	$obj->addChild('seo_google_code',		'');
	$obj->addChild('seo_bing_code',			'');
	$obj->addChild('seo_author',			'');
	$obj->addChild('friendly_urls',			0);

	// Default Homepage
	$obj->addChild('default_homepage',		0);

	$obj->asXml( FILE_XML_CONFIG );

	// categories.xml
	$xml  = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
	$xml .= '<categories autoinc="3">';
	$xml .= '</categories>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);
	$node = $obj->addChild('category', '');
	$node->addAttribute('id',0);
	$node->addAttribute('name', $_LANG['UNCATEGORIZED']);
	$node->addAttribute('slug', 'uncategorized');
	$node->addAttribute('position', 1);
	$node = $obj->addChild('category', '');
	$node->addAttribute('id',1);
	$node->addAttribute('name', $_LANG['MUSIC']);
	$node->addAttribute('slug', 'music');
	$node->addAttribute('position', 2);
	$node = $obj->addChild('category', '');
	$node->addAttribute('id',2);
	$node->addAttribute('name', $_LANG['VIDEOS']);
	$node->addAttribute('slug', 'videos');
	$node->addAttribute('position', 3);
	$obj->asXml( FILE_XML_CATEGORIES );

	// tags.xml
	$xml  = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
	$xml .= '<tags autoinc="0">';
	$xml .= '<list></list>';
	$xml .= '<links></links>';
	$xml .= '</tags>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);
	$obj->asXml( FILE_XML_TAGS );

	// comments.xml
	$xml  = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
	$xml .= '<comments autoinc="0">';
	$xml .= '</comments>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);
	$obj->addChild('moderate', 1);
	$obj->addChild('sanitize', 1);
	$obj->addChild('monitor_enable', 0);
	$obj->addChild('monitor_api_key', '');
	$obj->addChild('monitor_spam_control', '0.75');
	$obj->addChild('monitor_auto_delete', 0);
	$obj->addChild('disqus_shortname', '');
	$obj->addChild('facebook_appid', '');
	$obj->asXml( FILE_XML_COMMENTS );

	// posts.xml
	$xml  = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
	$xml .= '<post autoinc="1">';
	$xml .= '<friendly></friendly>';
	$xml .= '</post>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);

	$obj->asXml( FILE_XML_POSTS );

	// pages.xml
	$xml  = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
	$xml .= '<pages autoinc="1">';
	$xml .= '<friendly></friendly>';
	$xml .= '</pages>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);

	$obj->asXml( FILE_XML_PAGES );

	// notifications.xml
	$xml  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
	$xml .= '<notifications>';
	$xml .= '</notifications>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);
	$obj->asXml( FILE_XML_NOTIFICATIONS );

	// users.xml
	$xml  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
	$xml .= '<users>';
	$xml .= '</users>';
	$obj = new NBXML($xml, 0, FALSE, '', FALSE);
	$node = $obj->addGodChild('user', array('username'=>$_POST['username']));
	$node->addChild('id', 0);
	$node->addChild('session_fail_count', 0);
	$node->addChild('session_date', 0);
	$obj->asXml( FILE_XML_USERS );

	// shadow.php
	$new_salt = Text::random_text(11);
	$new_hash = Crypt::get_hash($_POST['password'],$new_salt);
	$text = '<?php $_USER[0]["uid"] = "0"; $_USER[0]["username"] = "'.$_POST['username'].'"; $_USER[0]["password"] = "'.$new_hash.'"; $_USER[0]["salt"] = "'.$new_salt.'"; $_USER[0]["email"] = "'.$_POST['email'].'"; ?>';
	$file = fopen(FILE_SHADOW, 'w');
	fputs($file, $text);
	fclose($file);

	// keys.php
	$key1 = Crypt::get_hash(Text::random_text(11));
	$key2 = Crypt::get_hash(Text::random_text(11));
	$key3 = Crypt::get_hash(Text::random_text(11));
	$text = '<?php $_KEYS[0] = "nibbl'.$key1.'"; $_KEYS[1] = "eblog'.$key2.'"; $_KEYS[2] = "rulez'.$key3.'"; ?>';
	$file = fopen(FILE_KEYS, 'w');
	fputs($file, $text);
	fclose($file);

	// welcome post
	$content  = '<p>'.$_LANG['WELCOME_POST_LINE1'].'</p>';
	$content .= '<p>'.$_LANG['WELCOME_POST_LINE2'].'</p>';
	$content .= '<p>'.$_LANG['WELCOME_POST_LINE3'].'</p>';

	$content = Text::replace_assoc(
			array(
				'{{DASHBOARD_LINK}}'=>'<a href="./admin.php">'.$blog_address.'admin.php</a>',
				'{{FACEBOOK_LINK}}'=>'<a target="_blank" href="https://www.facebook.com/nibbleblog">Facebook</a>',
				'{{TWITTER_LINK}}'=>'<a target="_blank" href="https://twitter.com/nibbleblog">Twitter</a>',
				'{{GOOGLEPLUS_LINK}}'=>'<a target="_blank" href="https://plus.google.com/+Nibbleblog">Google+</a>'
			),
			$content
	);

	$_DB_POST = new DB_POSTS(FILE_XML_POSTS);
	$_DB_POST->add( array('id_user'=>0, 'id_cat'=>0, 'type'=>'simple', 'description'=>$_LANG['WELCOME_POST_TITLE'], 'title'=>$_LANG['WELCOME_POST_TITLE'], 'content'=>$content, 'allow_comments'=>'1', 'sticky'=>'0', 'slug'=>'welcome-post') );

	// Plugins
	$plugins = array('pages', 'categories', 'latest_posts');
	foreach($plugins as $plugin)
	{
		include_once(PATH_PLUGINS.$plugin.'/plugin.bit');
		$class = 'PLUGIN_'.strtoupper($plugin);
		$obj = new $class;

		if( @!include(PATH_PLUGINS.$plugin.'/languages/'.$_GET['language'].'.bit') )
			include(PATH_PLUGINS.$plugin.'/languages/en_US.bit');

		$merge = array_merge($_LANG, $_PLUGIN_CONFIG['LANG']);

		$obj->set_lang($merge);

		$obj->set_attributes(
		array(
			'name'=>$_PLUGIN_CONFIG['LANG']['NAME'],
			'description'=>$_PLUGIN_CONFIG['LANG']['DESCRIPTION'],
			'author'=>$_PLUGIN_CONFIG['DATA']['author'],
			'version'=>$_PLUGIN_CONFIG['DATA']['version'],
			'url'=>$_PLUGIN_CONFIG['DATA']['url'],
			'display'=>isset($_PLUGIN_CONFIG['DATA']['display'])?false:true
		));

		include(PATH_PLUGINS.$plugin.'/languages/en_US.bit');
		$obj->set_slug_name($_PLUGIN_CONFIG['LANG']['NAME']);

		$obj->install(0);
	}

	$installation_complete = true;
//}
?>